#include "uvgv3crtp/v3c_api.h"

#include "V3C_Receiver.h"
#include "V3C_Sender.h"
#include "Sample_Stream.h"

#include <type_traits>
#include <utility>
#include <array>
#include <sstream>
#include <iterator>

namespace uvgV3CRTP {

  template class V3C_State<V3C_Sender>;
  template class V3C_State<V3C_Receiver>;


  // Some macros for handling exceptions
#define V3C_STATE_TRY(state)          \
  auto& _err = state->error_;         \
  auto& _err_msg = state->error_msg_; \
  try
#define V3C_STATE_CATCH(return_error)                            \
  catch (const TimeoutException& e) {                            \
    _err = ERROR_TYPE::TIMEOUT;                                  \
    _err_msg = std::string("Timeout: ") + e.what();              \
  }                                                              \
  catch (const TimestampException& e) {                          \
    _err = ERROR_TYPE::TIMESTAMP;                                \
    _err_msg = std::string("Timestamp error: ") + e.what();      \
  }                                                              \
  catch (const ConnectionException& e) {                         \
    _err = ERROR_TYPE::CONNECTION;                               \
    _err_msg = std::string("Connection error: ") + e.what();     \
  }                                                              \
  catch (const ParseException& e) {                              \
    _err = ERROR_TYPE::PARSE;                                    \
    _err_msg = std::string("Parse error: ") + e.what();          \
  }                                                              \
  catch (const std::exception& e) {                              \
    _err = ERROR_TYPE::GENERAL;                                  \
    _err_msg = std::string("Undefined exception: ") + e.what();  \
  }                                                              \
  catch (...) {                                                  \
    _err = ERROR_TYPE::GENERAL;                                  \
    _err_msg = std::string("Unknown exception");                 \
  }                                                              \
  if constexpr (return_error) {                                  \
    return ([&]() -> ERROR_TYPE { return _err; }());             \
  }                                                              \
  do{}while(false)

  namespace {
    using Iterator = typename Sample_Stream<SAMPLE_STREAM_TYPE::V3C>::Iterator;
  }

  static inline Iterator& get_it(void * it_ptr)
  {
    return *(static_cast<Iterator*>(it_ptr));
  }
  static inline Iterator* get_it_ptr(void * it_ptr)
  {
    return static_cast<Iterator*>(it_ptr);
  }
  static inline void* unget_it_ptr(Iterator * it_ptr)
  {
    return static_cast<void *>(it_ptr);
  }


  template<typename T>
  ERROR_TYPE V3C_State<T>::set_error(ERROR_TYPE error, std::string msg) const noexcept
  {
    error_ = error;
    error_msg_ = std::string(msg);
    return error_;
  }

  template<typename T>
  bool V3C_State<T>::validate_data() const noexcept
  {
    if (!data_)
    {
      set_error(ERROR_TYPE::DATA, "No data exists");
      return false;
    }
    return true;
  }

  template<typename T>
  bool V3C_State<T>::validate_nodata() const noexcept
  {
    if (data_)
    {
      set_error(ERROR_TYPE::DATA, "Data already exists");
      return false;
    }
    return true;
  }

  template<typename T>
  bool V3C_State<T>::validate_cur_gof(bool check_eos) const noexcept
  {
    if (!cur_gof_it_ || !is_gof_it_valid_)
    {
      set_error(ERROR_TYPE::INVALID_IT, "Gof iterator not initialized correctly");
      return false;
    }
    else if (check_eos && get_it(cur_gof_it_) == data_->end())
    {
      set_error(ERROR_TYPE::EOS, "End of stream reached");
      return false;
    }
    return true;
  }

  template<typename T, size_t... Is>
  static constexpr std::array<T, sizeof...(Is)> to_array(T val, std::index_sequence<Is...>)
  {
    return { ((void)Is, val)... };
  }
  template<size_t N, typename T>
  static constexpr std::array<T, N> to_array(T val)
  {
    return to_array(val, std::make_index_sequence<N>());
  }

  template<typename T>
  V3C_State<T>::V3C_State(INIT_FLAGS flags, const char* endpoint_address, uint16_t port) noexcept :
    connection_(nullptr),
    flags_(flags),
    data_(nullptr),
    cur_gof_it_(nullptr),
    is_gof_it_valid_(false),
    cur_gof_ind_(0),
    error_(ERROR_TYPE::OK), error_msg_("")
  {
    const std::array<uint16_t, NUM_V3C_UNIT_TYPES> ports = to_array<NUM_V3C_UNIT_TYPES>(port) ;
    init_connection(flags, endpoint_address, ports.data());
  }
  template<typename T>
  V3C_State<T>::V3C_State(INIT_FLAGS flags, const char* endpoint_address, uint16_t ports[NUM_V3C_UNIT_TYPES]) noexcept :
    connection_(nullptr), 
    flags_(flags), 
    data_(nullptr), 
    cur_gof_it_(nullptr), 
    is_gof_it_valid_(false),
    cur_gof_ind_(0),
    error_(ERROR_TYPE::OK), error_msg_("")
  {
    init_connection(flags, endpoint_address, ports);
  }

  template<typename T>
  V3C_State<T>::V3C_State(const uint8_t size_precision, INIT_FLAGS flags, const char* endpoint_address, uint16_t port) noexcept :
    connection_(nullptr),
    flags_(flags),
    data_(nullptr),
    cur_gof_it_(nullptr),
    is_gof_it_valid_(false),
    cur_gof_ind_(0),
    error_(ERROR_TYPE::OK), error_msg_("")
  {
    const std::array<uint16_t, NUM_V3C_UNIT_TYPES> ports = to_array<NUM_V3C_UNIT_TYPES>(port);
    init_connection(flags, endpoint_address, ports.data());
    init_sample_stream(size_precision);
  }

  template<typename T>
  V3C_State<T>::V3C_State(const uint8_t size_precision, INIT_FLAGS flags, const char* endpoint_address, uint16_t ports[NUM_V3C_UNIT_TYPES]) noexcept :
    connection_(nullptr), 
    flags_(flags), 
    data_(nullptr), 
    cur_gof_it_(nullptr), 
    is_gof_it_valid_(false), 
    cur_gof_ind_(0),
    error_(ERROR_TYPE::OK), error_msg_("")
  {
    init_connection(flags, endpoint_address, ports);
    init_sample_stream(size_precision);
  }
  
  template<typename T>
  V3C_State<T>::V3C_State(const char* bitstream, size_t len, INIT_FLAGS flags, const char* endpoint_address, uint16_t port) noexcept :
    connection_(nullptr),
    flags_(flags),
    data_(nullptr),
    cur_gof_it_(nullptr),
    is_gof_it_valid_(false),
    cur_gof_ind_(0),
    error_(ERROR_TYPE::OK), error_msg_("")
  {    
    const std::array<uint16_t, NUM_V3C_UNIT_TYPES> ports = to_array<NUM_V3C_UNIT_TYPES>(port);
    init_connection(flags, endpoint_address, ports.data());
    init_sample_stream(bitstream, len);
  }
  template<typename T>
  V3C_State<T>::V3C_State(const char* bitstream, size_t len, INIT_FLAGS flags, const char* endpoint_address, uint16_t ports[NUM_V3C_UNIT_TYPES]) noexcept :
    connection_(nullptr), 
    flags_(flags), 
    data_(nullptr), 
    cur_gof_it_(nullptr), 
    is_gof_it_valid_(false), 
    cur_gof_ind_(0),
    error_(ERROR_TYPE::OK), error_msg_("")
  {
    init_connection(flags, endpoint_address, ports);
    init_sample_stream(bitstream, len);
  }

  template<typename T>
  V3C_State<T>::~V3C_State() noexcept
  {
    if (connection_) delete connection_;
    connection_ = nullptr;
    clear_sample_stream();
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::init_sample_stream(const uint8_t size_precision) noexcept
  {
    if (!validate_nodata()) return get_error_flag();
    data_ = new Sample_Stream<SAMPLE_STREAM_TYPE::V3C>(size_precision);
    return ERROR_TYPE::OK;
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::init_sample_stream(const char * bitstream, size_t len) noexcept
  {
    if (!validate_nodata()) return get_error_flag();
    V3C_STATE_TRY(this)
    {
      data_ = new Sample_Stream<SAMPLE_STREAM_TYPE::V3C>(V3C::parse_bitstream(bitstream, len));
      // If this is a sender state, init timestamps for the new data
      if constexpr (std::is_same<T, V3C_Sender>::value)
      {
        this->set_timestamps(static_cast<V3C_Sender*>(connection_)->get_initial_timestamp());
      }
    }
    V3C_STATE_CATCH(false);

    return init_cur_gof();
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::append_to_sample_stream(const char* bitstream, size_t len, bool has_sample_stream_headers) noexcept
  {
    if (!validate_data()) return get_error_flag();
    // Adding to sample stream will invalidate the current gof iterator
    is_gof_it_valid_ = false;
    V3C_STATE_TRY(this)
    {
      // If this is a sender state, init timestamps for new data if sample stream is empty
      [[maybe_unused]] const bool is_empty = data_->num_samples() == 0;
      if (has_sample_stream_headers)
      {
        data_->push_back(
          V3C::parse_bitstream(bitstream, len)
        );
      }
      else
      {
        data_->push_back(
          V3C_Unit(bitstream, len)
        );
      }
      // If this is a sender state, init timestamps for the new data
      if constexpr (std::is_same<T, V3C_Sender>::value)
      {
        if (is_empty) {
          this->set_timestamps(static_cast<V3C_Sender*>(connection_)->get_initial_timestamp());
        }
      }
    }
    V3C_STATE_CATCH(false);
  
    return gof_at(cur_gof_ind_);
  }

  template<typename T>
  void V3C_State<T>::clear_sample_stream() noexcept
  {
    if constexpr (std::is_same<T, V3C_Sender>::value)
    {
      if (data_ && data_->num_samples() > 0 && connection_ && static_cast<V3C_Sender*>(connection_)->is_initial_timestamp_set())
      {
        // Set initial timestamp to last timestamp + frame duration so that if new data is added, timestamps are continuous
        static_cast<V3C_Sender*>(connection_)->set_initial_timestamp(
          V3C::calc_new_timestamp(data_->back().get_timestamp(), DEFAULT_FRAME_RATE, RTP_CLOCK_RATE)
        );
      }
    }
    if (data_)       delete data_;
    if (cur_gof_it_) delete get_it_ptr(cur_gof_it_);
    data_ = nullptr;
    cur_gof_it_ = nullptr;
    is_gof_it_valid_ = false;
    cur_gof_ind_ = 0;
  }

  template<typename T>
  void V3C_State<T>::init_connection(INIT_FLAGS flags, const char* endpoint_address, const uint16_t ports[NUM_V3C_UNIT_TYPES]) noexcept
  {
    if (connection_)
    {
      set_error(ERROR_TYPE::CONNECTION, "A connection object already exists");
      return;
    }
    V3C_STATE_TRY(this)
    {
      connection_ = new T(flags, endpoint_address, ports);
    }
    V3C_STATE_CATCH(false);
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::init_cur_gof(size_t to, bool reverse) noexcept
  {
    if ((cur_gof_it_ && is_gof_it_valid_) || !data_)
    {
      return set_error(ERROR_TYPE::DATA, "Gof iterator already initialized or no data exists");
    }
    if (cur_gof_it_ && !is_gof_it_valid_) {
      delete get_it_ptr(cur_gof_it_);
      cur_gof_it_ = nullptr;
    }
    if (to >= data_->num_samples()) {
      return set_error(ERROR_TYPE::INVALID_IT, "Invalid iterator position: " + std::to_string(to) + ", data has only " + std::to_string(data_->num_samples()) + " GoFs");
    }
    if (reverse)
    {
      cur_gof_it_ = unget_it_ptr(new Iterator(std::prev(data_->end(), to + 1)));
      cur_gof_ind_ = data_->num_samples() - to - 1; // Reverse index
    }
    else
    {
      cur_gof_it_ = unget_it_ptr(new Iterator(std::next(data_->begin(), to)));
      cur_gof_ind_ = to;
    }
    is_gof_it_valid_ = true;

    return ERROR_TYPE::OK;
  }

  template<typename T>
  void V3C_State<T>::set_timestamps(const uint32_t init_timestamp) noexcept
  {
    if (!validate_data()) return;

    uint32_t timestamp = init_timestamp;
    for (const auto& gof : *data_)
    {
      gof.set_timestamp(timestamp);
      timestamp = V3C::calc_new_timestamp(timestamp, DEFAULT_FRAME_RATE, RTP_CLOCK_RATE);
    }
  }

  template<typename T>
  char* V3C_State<T>::get_bitstream(size_t* length) const noexcept
  {
    if (!validate_data()) return nullptr;

    V3C_STATE_TRY(this)
    {
      if (length) *length = data_->size();
      return data_->get_bitstream().release();
    }
    V3C_STATE_CATCH(false);
    
    return nullptr;
  }

  template<typename T>
  char* V3C_State<T>::get_bitstream_cur_gof(size_t* length) const noexcept
  {
    if (!validate_data()) return nullptr;
    if (!validate_cur_gof()) return nullptr;

    V3C_STATE_TRY(this)
    {
      if (length) *length = data_->size(get_it(cur_gof_it_));
      return data_->get_bitstream(get_it(cur_gof_it_)).release();
    }
    V3C_STATE_CATCH(false);

    return nullptr;
  }

  template<typename T>
  char* V3C_State<T>::get_bitstream_cur_gof_unit(const V3C_UNIT_TYPE type, size_t* length) const noexcept
  {
    if (!validate_data()) return nullptr;
    if (!validate_cur_gof()) return nullptr;

    V3C_STATE_TRY(this)
    {
      if (length) *length = data_->size(get_it(cur_gof_it_), type);
      return data_->get_bitstream(get_it(cur_gof_it_), type).release();
    }
    V3C_STATE_CATCH(false);

    return nullptr;
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::first_gof() noexcept
  {
    if (!validate_data()) return get_error_flag();

    is_gof_it_valid_ = false; //Invalidate iterator so it can be initialized
    return init_cur_gof();
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::last_gof() noexcept
  {
    if (!validate_data()) return get_error_flag();

    is_gof_it_valid_ = false; //Invalidate iterator so it can be initialized
    return init_cur_gof(0, true);
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::gof_at(size_t i) noexcept
  {
    if (!validate_data()) return get_error_flag();

    is_gof_it_valid_ = false; //Invalidate iterator so it can be initialized
    return init_cur_gof(i);
  }

  template<typename T>
  size_t V3C_State<T>::cur_gof_ind() const noexcept
  {
    if (!validate_data()) return 0;
    if (!validate_cur_gof(false)) return 0;
    return cur_gof_ind_;
  }

  template<typename T>
  size_t V3C_State<T>::num_gofs() const noexcept
  {
    if (!validate_data()) return 0;
    return data_->num_samples();
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::next_gof() noexcept
  {
    if (!validate_data()) return get_error_flag();
    if (!validate_cur_gof(false)) return get_error_flag();

    ++get_it(cur_gof_it_);
    ++cur_gof_ind_;

    if (get_it(cur_gof_it_) == data_->end()) return set_error(ERROR_TYPE::EOS, "End of stream reached");

    return ERROR_TYPE::OK;
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::prev_gof() noexcept
  {
    if (!validate_data()) return get_error_flag();
    if (!validate_cur_gof(false)) return get_error_flag();

    // Only decrement iterator if not at the first element
    if (get_it(cur_gof_it_) != data_->begin())
    {
      --get_it(cur_gof_it_);
      --cur_gof_ind_;
    }

    if (get_it(cur_gof_it_) == data_->end()) return set_error(ERROR_TYPE::EOS, "End of stream reached");

    return ERROR_TYPE::OK;
  }

  template<typename T>
  bool V3C_State<T>::cur_gof_has_unit(V3C_UNIT_TYPE unit) const noexcept
  {
    if (!validate_data()) return false;
    if (!validate_cur_gof()) return false;

    return (*get_it(cur_gof_it_)).find(unit) != (*get_it(cur_gof_it_)).end();
  }

  template<typename T>
  bool V3C_State<T>::cur_gof_is_full() const noexcept
  {
    if (!validate_data()) return false;
    if (!validate_cur_gof()) return false;

    for (const auto type : V3C::unit_types_from_init_flag(flags_))
    {
      if (!cur_gof_has_unit(type)) return false;
    }
    return true;
  }

  ERROR_TYPE send_bitstream(V3C_State<V3C_Sender>* state) noexcept
  {
    if (!state->validate_data()) return state->get_error_flag();

    V3C_STATE_TRY(state)
    {
      state->connection_->send_bitstream(*state->data_, SEND_FRAME_RATE);
    }
    V3C_STATE_CATCH(true);
  }

  ERROR_TYPE send_gof(V3C_State<V3C_Sender>* state) noexcept
  {
    if (!state->validate_data()) return state->get_error_flag();
    if (!state->validate_cur_gof()) return state->get_error_flag();

    V3C_STATE_TRY(state)
    {
      state->connection_->send_gof(*get_it(state->cur_gof_it_));
    }
    V3C_STATE_CATCH(true);
  }

  ERROR_TYPE send_unit(V3C_State<V3C_Sender>* state, V3C_UNIT_TYPE type) noexcept
  {
    if (!state->validate_data()) return state->get_error_flag();
    if (!state->validate_cur_gof()) return state->get_error_flag();

    V3C_STATE_TRY(state)
    {
      state->connection_->send_v3c_unit((*get_it(state->cur_gof_it_)).get(type));
    }
    V3C_STATE_CATCH(true);
  }


  static V3C_Unit::V3C_Unit_Header make_header_from_struct(const HeaderStruct& hs)
  {
    switch (V3C_Unit::V3C_Unit_Header::vuh_to_type(hs.vuh_unit_type))
    {
    case V3C_VPS:
      return V3C_Unit::V3C_Unit_Header(V3C_VPS);

    case V3C_AD:
      return V3C_Unit::V3C_Unit_Header(
        hs.vuh_unit_type,
        hs.vuh_v3c_parameter_set_id,
        hs.vuh_atlas_id
      );

    case V3C_OVD:
      return V3C_Unit::V3C_Unit_Header(
        hs.vuh_unit_type,
        hs.vuh_v3c_parameter_set_id,
        hs.vuh_atlas_id
      );

    case V3C_GVD:
      return V3C_Unit::V3C_Unit_Header(
        hs.vuh_unit_type,
        hs.vuh_v3c_parameter_set_id,
        hs.vuh_atlas_id,
        hs.vuh_map_index,
        hs.vuh_auxiliary_video_flag
      );

    case V3C_AVD:
      return V3C_Unit::V3C_Unit_Header(
        hs.vuh_unit_type,
        hs.vuh_v3c_parameter_set_id,
        hs.vuh_atlas_id,
        hs.vuh_attribute_index,
        hs.vuh_attribute_partition_index,
        hs.vuh_map_index,
        hs.vuh_auxiliary_video_flag
      );

    case V3C_PVD:
      return V3C_Unit::V3C_Unit_Header(
        hs.vuh_unit_type,
        hs.vuh_v3c_parameter_set_id,
        hs.vuh_atlas_id
      );

    case V3C_CAD:
      return V3C_Unit::V3C_Unit_Header(
        hs.vuh_unit_type,
        hs.vuh_v3c_parameter_set_id
      );

    default:
      // TODO: Raise error
      return V3C_Unit::V3C_Unit_Header();
    }
  }

  static std::map<V3C_UNIT_TYPE, const V3C_Unit::V3C_Unit_Header> make_header_map_from_struct_array(const HeaderStruct hss[NUM_V3C_UNIT_TYPES])
  {
    std::map<V3C_UNIT_TYPE, const V3C_Unit::V3C_Unit_Header> headers;
    for (size_t t = 0; t < NUM_V3C_UNIT_TYPES; t++)
    {
      headers.emplace(V3C_UNIT_TYPE(t), make_header_from_struct(hss[t]));
    }
    return headers;
  }

  template <typename E, typename T, std::size_t N, typename = typename std::enable_if<std::is_enum<E>::value>::type>
  static std::map<E, T> array_to_enum_map(const T arr[N])
  {
    std::map<E, T> enum_map;
    for (size_t t = 0; t < N; t++)
    {
      enum_map[E(t)] = arr[t];
    }
    return enum_map;
  }

  static void check_timestamps(Iterator from, const Iterator to)
  {
    if (from == to) return; // Nothing to check

    for (Iterator next = std::next(from); next != to; ++from, ++next)
    {
      const auto expected_timestamp = V3C::calc_new_timestamp((*from).get_timestamp(), DEFAULT_FRAME_RATE, RTP_CLOCK_RATE);
      if ((*next).get_timestamp() != expected_timestamp)
      {
        throw TimestampException("Received GoF timestamp " + std::to_string((*next).get_timestamp()) + " does not match expected timestamp " + std::to_string(expected_timestamp));
      }
    }
  }

  ERROR_TYPE receive_bitstream(V3C_State<V3C_Receiver>* state, const uint8_t v3c_size_precision, const uint8_t size_precisions[NUM_V3C_UNIT_TYPES], const size_t expected_num_gofs, const size_t num_nalus[NUM_V3C_UNIT_TYPES], const HeaderStruct header_defs[NUM_V3C_UNIT_TYPES], int timeout) noexcept
  {
    if (!state->validate_nodata()) return state->get_error_flag();

    V3C_STATE_TRY(state)
    {
      state->data_ = new Sample_Stream<SAMPLE_STREAM_TYPE::V3C>(
        state->connection_->receive_bitstream(
          v3c_size_precision,
          array_to_enum_map<V3C_UNIT_TYPE, uint8_t, NUM_V3C_UNIT_TYPES>(size_precisions),
          expected_num_gofs,
          array_to_enum_map<V3C_UNIT_TYPE, size_t, NUM_V3C_UNIT_TYPES>(num_nalus),
          make_header_map_from_struct_array(header_defs),
          timeout)
      );

      state->init_cur_gof();

      // Check if receive buffer has leftover data and raise a warning if it does
      if (state->connection_->receive_buffer_size() > 0)
      {
        throw TimestampException("Receive buffer has leftover data after receiving bitstream. This may indicate unexpected timestamps or heavy reordering of nalus.");
      }

      // Also check that the timestamp is as expected
      check_timestamps(state->data_->begin(), state->data_->end());
    }
    V3C_STATE_CATCH(true);
  }

  ERROR_TYPE receive_gof(V3C_State<V3C_Receiver>* state, const uint8_t size_precisions[NUM_V3C_UNIT_TYPES], const size_t num_nalus[NUM_V3C_UNIT_TYPES], const HeaderStruct header_defs[NUM_V3C_UNIT_TYPES], int timeout) noexcept
  {
    if (!state->validate_data()) return state->get_error_flag();
    
    V3C_STATE_TRY(state)
    {
      if (!state->data_)
      {
        return state->set_error(ERROR_TYPE::DATA, "No data exists");

      }
      try {
        state->is_gof_it_valid_ = false;
        state->data_->push_back(
          state->connection_->receive_gof(
            array_to_enum_map<V3C_UNIT_TYPE, uint8_t, NUM_V3C_UNIT_TYPES>(size_precisions),
            array_to_enum_map<V3C_UNIT_TYPE, size_t, NUM_V3C_UNIT_TYPES>(num_nalus),
            make_header_map_from_struct_array(header_defs),
            timeout,
            true
          )
        );
      }
      catch (const TimeoutException& e)
      {
        // Timeout trying to receive more gofs
        std::cerr << "Timeout: " << e.what() << std::endl;
        throw e;
      }

      if (!state->cur_gof_it_)
      {
        state->init_cur_gof();
      }
      else
      {
        state->gof_at(state->cur_gof_ind_); // Reset gof to previous position
      }

      // Try processing any leftover data in the receive buffer to avoid buildup
      state->connection_->push_buffer_to_sample_stream(*state->data_);
      // throw warning if there is still leftover data in the receive buffer
      if (state->connection_->receive_buffer_size() > 0)
      {
        throw TimestampException("Receive buffer has leftover data after receiving GoF. This may indicate unexpected timestamps or heavy reordering of nalus.");
      }

      // Also check that the timestamp is as expected
      if (state->data_->num_samples() > 1) check_timestamps(std::prev(state->data_->end(), 2), state->data_->end());
    }
    V3C_STATE_CATCH(true);
  }

  ERROR_TYPE receive_unit(V3C_State<V3C_Receiver>* state, const V3C_UNIT_TYPE unit_type, const uint8_t size_precision, const size_t expected_size, const HeaderStruct header_def, int timeout) noexcept
  {
    if (!state->validate_data()) return state->get_error_flag();
    
    V3C_STATE_TRY(state)
    {
      if (!state->data_)
      {
        return state->set_error(ERROR_TYPE::DATA, "No data exists");
      }

      try {
        state->is_gof_it_valid_ = false; // Might allocate a new gof so it may not be valid anymore
        state->data_->push_back(
          state->connection_->receive_v3c_unit(
            unit_type,
            size_precision,
            expected_size,
            make_header_from_struct(header_def),
            timeout,
            true // TODO: size is taken as the number of nalus add option to give size in bytes?
          )
        );
      }
      catch (const TimeoutException& e)
      {
        // Timeout trying to receive v3c unit
        std::cerr << "Timeout: " << e.what() << " in unit type id " << static_cast<int>(unit_type) << std::endl;
        throw TimeoutException(std::string(e.what()) + " in unit type id " + std::to_string(unit_type));
      }

      if (!state->cur_gof_it_)
      {
        state->init_cur_gof();
      }
      else
      {
        state->gof_at(state->cur_gof_ind_); // Reset gof to previous position
      }

      // Try processing any leftover data in the receive buffer to avoid buildup
      state->connection_->push_buffer_to_sample_stream(*state->data_, unit_type);
      // throw warning if there is still leftover data in the receive buffer
      if (state->connection_->receive_buffer_size(unit_type) > 0)
      {
        throw TimestampException("Receive buffer has leftover data after receiving unit (type " + std::to_string(static_cast<int>(unit_type)) + ".This may indicate unexpected timestamps or heavy reordering of nalus.");
      }

      // Also check that the timestamp is as expected
      if (state->data_->num_samples() > 1) check_timestamps(std::prev(state->data_->end(), 2), state->data_->end());
    }
    V3C_STATE_CATCH(true);
  }

  ERROR_TYPE install_receive_hook(V3C_State<V3C_Receiver>* state, const V3C_UNIT_TYPE type, void* arg, void(*hook)(void*, uvgrtp::frame::rtp_frame*)) noexcept
  {
    if (!state->connection_)
    {
      return state->set_error(ERROR_TYPE::CONNECTION, "No connection exists");
    }
    V3C_STATE_TRY(state)
    {
      state->connection_->install_receive_hook(type, arg, hook);
    }
    V3C_STATE_CATCH(true);
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::parse_bitstream_info_string(const char* const in_data, size_t in_len, INFO_FMT fmt, BitstreamInfo* out_info) noexcept
  {
    if (out_info == nullptr || in_data == nullptr) return ERROR_TYPE::OK;
    //if (field_fmt != INFO_FMT::RAW && field_fmt != INFO_FMT::BASE64)
    //{
    //  std::cerr << "Error: Only RAW and BASE64 formats are supported for out-of-band info parsing." << std::endl;
    //  return false; // Only RAW and BASE64 formats are supported
    //}
    V3C_STATE_TRY(this)
    {
      // Write in data to string stream
      std::stringstream stream(fmt == INFO_FMT::RAW ? std::ios::in | std::ios::out | std::ios::binary : std::ios::in | std::ios::out);
      stream.write(in_data, in_len);

      // Parse the out-of-band info
      auto out_data = V3C::read_out_of_band_info<V3C::InfoDataType, Sample_Stream<SAMPLE_STREAM_TYPE::V3C>>(stream, fmt, fmt, flags_);
      V3C::populate_bitstream_info(out_data, *out_info);
    }
    V3C_STATE_CATCH(true);
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::parse_unit_info_string(const char* const in_data, size_t in_len, HeaderStruct* header_out[NUM_V3C_UNIT_TYPES], INFO_FMT field_fmt, INFO_FMT value_fmt) const noexcept
  {
    if (header_out == nullptr || in_data == nullptr) return ERROR_TYPE::OK;
    // Don't write anything if both formats are NONE
    if (field_fmt == INFO_FMT::NONE && value_fmt == INFO_FMT::NONE) return ERROR_TYPE::OK;
    // Use field format for both if value format is NONE
    if (value_fmt == INFO_FMT::NONE) value_fmt = field_fmt;

    V3C_STATE_TRY(this)
    {
      // Write in data to string stream
      std::stringstream in_stream(value_fmt == INFO_FMT::RAW ? std::ios::in | std::ios::out | std::ios::binary : std::ios::in | std::ios::out);
      in_stream.write(in_data, in_len);

      // If value format is BASE64 need to use payload data type
      if (value_fmt == INFO_FMT::BASE64 || (value_fmt == INFO_FMT::NONE && field_fmt == INFO_FMT::BASE64))
      {
        auto out_data = V3C::read_out_of_band_info<V3C::PayloadDataType, V3C_Gof>(in_stream, field_fmt, value_fmt, flags_);

        // Populate header structs based on out_data
        V3C::populate_header(out_data, header_out);
      }
      else
      {
        auto out_data = V3C::read_out_of_band_info<V3C::HeaderDataType, V3C_Gof>(in_stream, field_fmt, value_fmt, flags_);

        // Populate header structs based on out_data
        V3C::populate_header(out_data, header_out);
      }

      return ERROR_TYPE::OK;
    }
    V3C_STATE_CATCH(true);
  }

  template<typename T>
  char* V3C_State<T>::parse_unit_info_string(const char* const in_data, size_t in_len, V3C_UNIT_TYPE type, HeaderStruct* header_out[NUM_V3C_UNIT_TYPES], size_t* out_len, INFO_FMT header_field_fmt, INFO_FMT header_value_fmt, INFO_FMT payload_field_fmt, INFO_FMT payload_value_fmt) const noexcept
  {
    if (in_data == nullptr) return nullptr;
    // Don't write anything if both formats are NONE
    if (header_field_fmt == INFO_FMT::NONE && header_value_fmt == INFO_FMT::NONE) return nullptr;
    if (payload_field_fmt == INFO_FMT::NONE && payload_value_fmt == INFO_FMT::NONE) return nullptr;
    // Use field format for both if value format is NONE
    if (header_value_fmt == INFO_FMT::NONE) header_value_fmt = header_field_fmt;
    if (payload_value_fmt == INFO_FMT::NONE) payload_value_fmt = payload_field_fmt;
    if (out_len) *out_len = 0;

    V3C_STATE_TRY(this)
    {
      // Write in data to string stream
      std::stringstream in_stream(
        (header_value_fmt == INFO_FMT::RAW
         || payload_value_fmt == INFO_FMT::RAW
        ) ? (std::ios::in | std::ios::out | std::ios::binary) : (std::ios::in | std::ios::out));
      in_stream.write(in_data, in_len);

      // Out stringstream for payload data if needed
      std::stringstream out_stream(
        (payload_value_fmt == INFO_FMT::RAW 
         || header_value_fmt == INFO_FMT::RAW
         || header_value_fmt == INFO_FMT::BASE64
         || payload_value_fmt == INFO_FMT::BASE64
        ) ? std::ios::in | std::ios::out | std::ios::binary : std::ios::in | std::ios::out);

      const auto type_flag = V3C::init_flags_from_unit_types({ type });

      // First parse header info if needed
      // If value format is BASE64 need to use payload data type
      if (header_value_fmt == INFO_FMT::BASE64 || (header_value_fmt == INFO_FMT::NONE && header_field_fmt == INFO_FMT::BASE64))
      {
        auto out_data = V3C::read_out_of_band_info<V3C::PayloadDataType, _V3C_Unit_Header_>(in_stream, header_field_fmt, header_value_fmt, type_flag);

        // Append binary data to out_stream
        out_stream << out_data.at(type).at(PAYLOAD_FIELDS::HEADER);
        V3C::populate_header(out_data, header_out); // Also write to header_out
      }
      else if (header_value_fmt != INFO_FMT::NONE || header_field_fmt != INFO_FMT::NONE)
      {
        auto out_data = V3C::read_out_of_band_info<V3C::HeaderDataType, V3C_Unit>(in_stream, header_field_fmt, header_value_fmt, type_flag);

        // Populate header structs based on out_data
        V3C::populate_header(out_data, header_out);
      }

      // Then parse payload info if needed
      if (payload_field_fmt != INFO_FMT::NONE || payload_value_fmt != INFO_FMT::NONE)
      {
        auto out_data = V3C::read_out_of_band_info<V3C::PayloadDataType, V3C_Unit>(in_stream, payload_field_fmt, payload_value_fmt, type_flag);
        // Append binary data to out_stream
        out_stream << out_data.at(type).at(PAYLOAD_FIELDS::PAYLOAD);
      }

      // Copy out_stream to char* if needed
      char* out_char = nullptr;
      size_t out_size = out_stream.str().size() + 1; // Include null-termination byte
      if (out_size > 1)
      {
        out_char = static_cast<char*>(malloc(out_size));
        if (out_char)
        {
          memcpy(out_char, out_stream.str().c_str(), out_size);
          if (out_len) *out_len = out_size;
        }
      }

      return out_char;
    }
    V3C_STATE_CATCH(false);

    return nullptr;
  }

  template<typename DataType, typename DataClass>
  static char * write_info(const DataClass& v3c_data, size_t* out_len, INFO_FMT field_fmt, INFO_FMT value_fmt = INFO_FMT::NONE)
  {
    // Don't write anything if both formats are NONE
    if (field_fmt == INFO_FMT::NONE && value_fmt == INFO_FMT::NONE) return nullptr;
    // Use field format for both if value format is NONE
    if (value_fmt == INFO_FMT::NONE) value_fmt = field_fmt;

    // Write info to string stream
    std::ostringstream oss(field_fmt == INFO_FMT::RAW ? std::ios::out | std::ios::binary : std::ios::out);
    V3C::write_out_of_band_info<DataType>(oss, v3c_data, field_fmt, value_fmt);
    std::string output = oss.str();

    // copy output to char*
    const size_t out_size = output.size() + 1; // Include null-termination byte
    if (out_len) *out_len = out_size;
    char * out_char = static_cast<char*>(malloc(out_size));
    if (out_char) memcpy(out_char, output.c_str(), out_size);

    return out_char;
  }

  template<typename T>
  char * V3C_State<T>::get_bitstream_info_string(const INFO_FMT fmt, size_t* out_len) const noexcept
  {
    if (!validate_data()) return nullptr;
    
    V3C_STATE_TRY(this)
    {
      return write_info<V3C::InfoDataType>(*data_, out_len, fmt);
    }
    V3C_STATE_CATCH(false);

    return nullptr;
  }

  template<typename T>
  char * V3C_State<T>::get_cur_gof_bitstream_info_string(const INFO_FMT fmt, size_t* out_len) const noexcept
  {
    if (!validate_data()) return nullptr;
    if (!validate_cur_gof()) return nullptr;
    
    V3C_STATE_TRY(this)
    {
      return write_info<V3C::InfoDataType>(*get_it(cur_gof_it_), out_len, fmt);
    }
    V3C_STATE_CATCH(false);

    return nullptr;
  }

  template<typename T>
  char * V3C_State<T>::get_cur_gof_bitstream_info_string(const V3C_UNIT_TYPE type, const INFO_FMT fmt, size_t* out_len) const noexcept
  {
    if (!validate_data()) return nullptr;
    if (!validate_cur_gof()) return nullptr;
    
    V3C_STATE_TRY(this)
    {
      return write_info<V3C::InfoDataType>((*get_it(cur_gof_it_)).get(type), out_len, fmt);
    }
    V3C_STATE_CATCH(false);

    return nullptr;
  }

  template<typename T>
  char* V3C_State<T>::get_cur_gof_unit_info_string(const INFO_FMT field_fmt , const INFO_FMT value_fmt, size_t* out_len) const noexcept
  {
    if (!validate_data()) return nullptr;
    if (!validate_cur_gof()) return nullptr;
    
    V3C_STATE_TRY(this)
    {
      // If value format is BASE64 need to use payload data type
      if (value_fmt == INFO_FMT::BASE64 || (value_fmt == INFO_FMT::NONE && field_fmt == INFO_FMT::BASE64))
      {
        return write_info<V3C::PayloadDataType>((*get_it(cur_gof_it_)), out_len, field_fmt, value_fmt);
      }

      return write_info<V3C::HeaderDataType>((*get_it(cur_gof_it_)), out_len, field_fmt, value_fmt);
    }
    V3C_STATE_CATCH(false);
    
    return nullptr;
  }

  template<typename T>
  char* V3C_State<T>::get_cur_gof_unit_info_string(const V3C_UNIT_TYPE type, const INFO_FMT header_field_fmt, const INFO_FMT header_value_fmt, const INFO_FMT payload_field_fmt, const INFO_FMT payload_value_fmt, size_t* out_len) const noexcept
  {
    if (!validate_data()) return nullptr;
    if (!validate_cur_gof()) return nullptr;
    
    V3C_STATE_TRY(this)
    {
      size_t header_len = 0; size_t payload_len = 0;
      char* header = write_info<V3C::HeaderDataType>((*get_it(cur_gof_it_)).get(type), &header_len, header_field_fmt, header_value_fmt);
      char* payload = write_info<V3C::PayloadDataType>((*get_it(cur_gof_it_)).get(type), &payload_len,
        payload_field_fmt, payload_value_fmt);

      if (header && payload)
      {
        header_len--; // Remove null-termination byte from header length as we will concatenate the two strings
        if (out_len) *out_len = header_len + payload_len;

        char* out_string = static_cast<char*>(malloc(header_len + payload_len));
        if (out_string)
        {
          memcpy(out_string, header, header_len);
          memcpy(out_string + header_len, payload, payload_len);
        }
        else if (out_len)
        {
          *out_len = 0;
        }
        if (header) free(header);
        if (payload) free(payload);

        return out_string;
      }
      else if (header)
      {
        if (out_len) *out_len = header_len;
        return header;
      }
      else if (payload)
      {
        if (out_len) *out_len = payload_len;
        return payload;
      }
    }
    V3C_STATE_CATCH(false);

    if (out_len) *out_len = 0;
    return nullptr;
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::print_state(const bool print_nalus, size_t num_gofs) const noexcept
  {
    if (!validate_data()) return get_error_flag();
    if (!validate_cur_gof(false)) return get_error_flag();

    V3C_STATE_TRY(this)
    {
      std::cout << "Sample stream of size " << data_->size() << " (v3c size precision: " << (int)data_->size_precision() << ") with state:" << std::endl;
      size_t gof_ind = 0;
      size_t ptr = SAMPLE_STREAM_HDR_LEN; // Track bitstream pointer, start at size precision
      for (const auto& gof : *data_)
      {
        if (gof_ind >= num_gofs)
        {
          std::cout << "." << std::endl << "." << std::endl << "." << std::endl << "(showing only the first " << (int)num_gofs << " Gofs)" << std::endl;
          break;
        }

        std::cout << "|--Gof #" << gof_ind << " (bitstream pos: " << (int)ptr << ", size (in sample stream): " << gof.size() << " (" << data_->size(std::next(data_->begin(), gof_ind)) << ")";
        if (gof.is_timestamp_set()) std::cout << ", timestamp: " << gof.get_timestamp();
        std::cout << ")";
        if (gof_ind == cur_gof_ind_) std::cout << " [cur gof]";
        std::cout << std::endl;

        for (const auto& [type, unit] : gof)
        {
          switch (type)
          {
          case V3C_VPS:
            std::cout << "|  |--V3C unit of type VPS ";
            break;
          case V3C_AD:
            std::cout << "|  |--V3C unit of type AD  ";
            break;
          case V3C_OVD:
            std::cout << "|  |--V3C unit of type OVD ";
            break;
          case V3C_GVD:
            std::cout << "|  |--V3C unit of type GVD ";
            break;
          case V3C_AVD:
            std::cout << "|  |--V3C unit of type AVD ";
            break;
          case V3C_PVD:
            std::cout << "|  |--V3C unit of type PVD ";
            break;
          case V3C_CAD:
            std::cout << "|  |--V3C unit of type CAD ";
            break;

          default:
            // TODO: give error
            std::cout << "    not a valid unit type";
            break;
          }
          std::cout << "(bitstream pos: " << (int)ptr << ", nal size precision: " << (int)unit.nal_size_precision() << ", size: " << unit.size();
          if (type != V3C_VPS)
          {
            std::cout << ", num nalu: " << unit.num_nalus();
          }
          std::cout << ")" << std::endl;

          if (print_nalus)
          {
            for (const auto& nal : unit.nalus())
            {
              std::cout << "|  |  |--NAL unit of type " << (int)nal.get().nal_unit_type() << " (size: " << nal.get().size() << ")" << std::endl;
            }
          }
          ptr += data_->size(std::next(data_->begin(), gof_ind), type);
        }

        gof_ind++;
      }
    }
    V3C_STATE_CATCH(true);
  }

  template<typename C, typename R, typename... P>
  static void print_info(const C* obj, R (C::*info_func)(P...) const, P... param)
  {
    //size_t len = 0;
    auto info = std::unique_ptr<char, decltype(&free)>((obj->*info_func)(param...), &free);
    if(info) std::cout << info.get() << std::endl;
  }

  template<typename T>
  void V3C_State<T>::print_bitstream_info(const INFO_FMT fmt) const noexcept
  {
    print_info(this, &V3C_State<T>::get_bitstream_info_string, fmt, static_cast<size_t*>(nullptr));
  }
  template<typename T>
  void V3C_State<T>::print_cur_gof_bitstream_info(const INFO_FMT fmt) const noexcept
  {
    print_info(this, static_cast<char*(V3C_State<T>::*)(INFO_FMT, size_t*)const>(&V3C_State<T>::get_cur_gof_bitstream_info_string), fmt, static_cast<size_t*>(nullptr));
  }
  template<typename T>
  void V3C_State<T>::print_cur_gof_bitstream_info(const V3C_UNIT_TYPE type, const INFO_FMT fmt) const noexcept
  {
    print_info(this, static_cast<char*(V3C_State<T>::*)(V3C_UNIT_TYPE, INFO_FMT, size_t*)const>(&V3C_State<T>::get_cur_gof_bitstream_info_string), type, fmt, static_cast<size_t*>(nullptr));
  }
  template<typename T>
  void V3C_State<T>::print_cur_gof_unit_info(const INFO_FMT field_fmt, const INFO_FMT value_fmt) const noexcept
  {
    print_info(this, static_cast<char* (V3C_State<T>::*)(INFO_FMT, INFO_FMT, size_t*)const>(&V3C_State<T>::get_cur_gof_unit_info_string), field_fmt, value_fmt, static_cast<size_t*>(nullptr));
  }
  template<typename T>
  void V3C_State<T>::print_cur_gof_unit_info(const V3C_UNIT_TYPE type, const INFO_FMT header_field_fmt, const INFO_FMT header_value_fmt, const INFO_FMT payload_field_fmt, const INFO_FMT payload_value_fmt) const noexcept
  {
    print_info(this, static_cast<char* (V3C_State<T>::*)(V3C_UNIT_TYPE, INFO_FMT, INFO_FMT, INFO_FMT, INFO_FMT, size_t*)const>(&V3C_State<T>::get_cur_gof_unit_info_string), type, header_field_fmt, header_value_fmt, payload_field_fmt, payload_value_fmt, static_cast<size_t*>(nullptr));
  }

  template<typename T>
  ERROR_TYPE V3C_State<T>::get_error_flag() const noexcept
  {
    return error_;
  }
  template<typename T>
  const char * V3C_State<T>::get_error_msg() const noexcept
  {
    return error_msg_.c_str();
  }
  template<typename T>
  void V3C_State<T>::reset_error_flag() const noexcept
  {
    error_ = ERROR_TYPE::OK;
    error_msg_ = std::string("");
  }
}