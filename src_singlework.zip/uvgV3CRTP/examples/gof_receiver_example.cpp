#include <uvgv3crtp/version.h>
#include <uvgv3crtp/v3c_api.h>

#include <iostream>
#include <fstream>
#include <bitset>
#include <cstdlib>

constexpr int EXPECTED_NUM_GOFs = 10;
constexpr int EXPECTED_NUM_VPSs = 10;
constexpr int EXPECTED_NUM_AD_NALU = 35;
constexpr int EXPECTED_NUM_OVD_NALU = 35;
constexpr int EXPECTED_NUM_GVD_NALU = 131;
constexpr int EXPECTED_NUM_AVD_NALU = 131;
constexpr uint8_t V3C_SIZE_PRECISION = 3;
constexpr uint8_t AtlasNAL_SIZE_PRECISION = 2;
constexpr uint8_t Video_SIZE_PRECISION = 4;

constexpr int TIMEOUT = 6000;
// Auto size precision may not match orig bitstream
constexpr bool AUTO_PRECISION_MODE = false;
constexpr bool AUTO_EXPECTED_NUM_MODE = false;

static void compare_bitstreams(uvgV3CRTP::V3C_State<uvgV3CRTP::V3C_Receiver>& state, std::unique_ptr<char[]>& buf, size_t length)
{
  std::cout << "Check bitstream was parsed correctly..." << std::endl;
  size_t rec_len = 0;
  auto rec = std::unique_ptr<char, decltype(&free)>(state.get_bitstream(&rec_len), &free); // Reconstruc bitstream from cur state
  bool diff = false;
  if (length != rec_len) {
    std::cout << "Error: Original bitstream size does not match reconstructed bitstream size: " << (int)length << " vs. " << (int)rec_len << std::endl;
    diff = true;
  }

  // Compare reconstructed file with the original one
  for (int i = 0; i < (length < rec_len ? length : rec_len); ++i) {
    if (buf[i] != rec.get()[i]) {
      diff = true;
      std::cout << "Difference found in " << i << std::endl;
      std::cout << "  orig byte: " << std::bitset<8>(buf[i]) << std::endl;
      std::cout << "   rec byte: " << std::bitset<8>(rec.get()[i]) << std::endl;

      break;
    }
  }
  if (!diff) {
    std::cout << "No differences found" << std::endl;
  }
}

int main(int argc, char* argv[]) {
  std::cout << "V3C RTP lib version: " << uvgV3CRTP::get_version() << std::endl;

  bool orig_available = false;
  bool out_of_band_available = false;
  std::unique_ptr<char[]> buf;
  size_t length = 0;
  if (argc >= 2) {
    //TODO: read orig bitstream for comparison
    std::cout << "Reading input bitstream... " << std::flush;
    // Open file
    std::ifstream bitstream(argv[1], std::ios::in | std::ios::binary);

    if (!bitstream.is_open()) {
      //TODO: Raise exception
      std::cerr << "File open failed";
      return EXIT_FAILURE;
    }

    //get length of file
    bitstream.seekg(0, bitstream.end);
    length = bitstream.tellg();
    bitstream.seekg(0, bitstream.beg);

    /* Read the file and its size */
    if (length == 0) {
      return EXIT_FAILURE; //TODO: Raise exception
    }
    std::cout << "Done" << std::endl;

    std::cout << "Reading file to buffer... " << std::flush;
    buf = std::make_unique<char[]>(length);
    if (buf == nullptr) return EXIT_FAILURE;//TODO: Raise exception

    // read into char*
    if (!(bitstream.read(buf.get(), length))) // read up to the size of the buffer
    {
      if (!bitstream.eof())
      {
        //TODO: Raise exception
        buf = nullptr; // Release allocated memory before returning nullptr
        return EXIT_FAILURE;
      }
    }
    std::cout << "Done" << std::endl;
    orig_available = true;
  }
  if (argc >= 3) {
    //TODO: read out-of-band data
    //std::cout << "Reading input bitstream... ";
    //// Open file
    //std::ifstream bitstream(argv[1]);

    //if (!bitstream.is_open()) {
    //  //TODO: Raise exception
    //  return EXIT_FAILURE;
    //}

    ////get length of file
    //bitstream.seekg(0, bitstream.end);
    //size_t length = bitstream.tellg();
    //bitstream.seekg(0, bitstream.beg);

    ///* Read the file and its size */
    //if (length == 0) {
    //  return EXIT_FAILURE; //TODO: Raise exception
    //}
    //std::cout << "Done" << std::endl;

    //std::cout << "Reading file to buffer... ";
    //auto buf = std::make_unique<char[]>(length);
    //if (buf == nullptr) return EXIT_FAILURE;//TODO: Raise exception

    //// read into char*
    //if (!(bitstream.read(buf.get(), length))) // read up to the size of the buffer
    //{
    //  if (!bitstream.eof())
    //  {
    //    //TODO: Raise exception
    //    buf = nullptr; // Release allocated memory before returning nullptr
    //    return EXIT_FAILURE;
    //  }
    //}
    //std::cout << "Done" << std::endl;
    out_of_band_available = true;
  }

  // ******** Initialize sample stream with default values or out_of_band info ***********
  //
  std::cout << "Initialize state... " << std::flush;
  uvgV3CRTP::V3C_State<uvgV3CRTP::V3C_Receiver> state(
    uvgV3CRTP::INIT_FLAGS::VPS |
    uvgV3CRTP::INIT_FLAGS::AD  |
    uvgV3CRTP::INIT_FLAGS::OVD |
    uvgV3CRTP::INIT_FLAGS::GVD |
    uvgV3CRTP::INIT_FLAGS::AVD,
    "127.0.0.1", 8890 //Receiver address and port
  ); // Create a new state in a receiver configuration

  // Define necessary information for receiving a v3c stream
  uint8_t v3c_size_precision   = AUTO_PRECISION_MODE ? static_cast<uint8_t>(-1) : V3C_SIZE_PRECISION;
  uint8_t atlas_size_precision = AUTO_PRECISION_MODE ? static_cast<uint8_t>(-1) : AtlasNAL_SIZE_PRECISION;
  uint8_t video_size_precision = Video_SIZE_PRECISION;//AUTO_PRECISION_MODE ? static_cast<uint8_t>(-1) : Video_SIZE_PRECISION;
  
  size_t expected_number_of_gof = AUTO_EXPECTED_NUM_MODE ? static_cast<size_t>(-1) : EXPECTED_NUM_GOFs;
  size_t num_vps                = AUTO_EXPECTED_NUM_MODE ? static_cast<size_t>(-1) : EXPECTED_NUM_VPSs;
  size_t num_ad_nalu            = AUTO_EXPECTED_NUM_MODE ? static_cast<size_t>(-1) : EXPECTED_NUM_AD_NALU;
  size_t num_ovd_nalu           = AUTO_EXPECTED_NUM_MODE ? static_cast<size_t>(-1) : EXPECTED_NUM_OVD_NALU;
  size_t num_gvd_nalu           = AUTO_EXPECTED_NUM_MODE ? static_cast<size_t>(-1) : EXPECTED_NUM_GVD_NALU;
  size_t num_avd_nalu           = AUTO_EXPECTED_NUM_MODE ? static_cast<size_t>(-1) : EXPECTED_NUM_AVD_NALU;
  size_t num_pvd_nalu           = 0;
  size_t num_cad_nalu           = 0;


  // Auto size precision if set to 0 (may not match orig bitstream)
  uint8_t size_precisions[uvgV3CRTP::NUM_V3C_UNIT_TYPES] = {
    0,
    atlas_size_precision,
    video_size_precision,
    video_size_precision,
    video_size_precision,
    video_size_precision,
    atlas_size_precision,
  };
  size_t num_nalus[uvgV3CRTP::NUM_V3C_UNIT_TYPES] = {
    num_vps,
    num_ad_nalu,
    num_ovd_nalu,
    num_gvd_nalu,
    num_avd_nalu,
    num_pvd_nalu,
    num_cad_nalu,
  };
  uvgV3CRTP::HeaderStruct header_defs[uvgV3CRTP::NUM_V3C_UNIT_TYPES] = {
    {uvgV3CRTP::V3C_VPS},
    {uvgV3CRTP::V3C_AD, 0, 0},
    {uvgV3CRTP::V3C_OVD, 0, 0},
    {uvgV3CRTP::V3C_GVD, 0, 0, 0, 0, 0, false},
    {uvgV3CRTP::V3C_AVD, 0, 0, 0, 0, 0, false},
    {uvgV3CRTP::V3C_PVD, 0, 0},
    {uvgV3CRTP::V3C_CAD, 0},
  };

  if (out_of_band_available)
  {
    //TODO: get out of band info
  }

  state.init_sample_stream(v3c_size_precision); //Init sample stream here since receive_gof() assumes data is initialized
  std::cout << "Done" << std::endl;
  //
  // ************************************************************************************

  // ******* Receive sample stream ********
  //
  std::cout << "Receiving bitstream... " << std::endl;

  while (state.get_error_flag() == uvgV3CRTP::ERROR_TYPE::OK && expected_number_of_gof > 0)
  {
    if (out_of_band_available)
    {
      //TODO: Get out of band info
    }
    std::cout << "  Receiving GoF..." << std::flush;
    uvgV3CRTP::receive_gof(&state, size_precisions, num_nalus, header_defs, TIMEOUT);

    if (!out_of_band_available)
    {
      //Increment VPS id in headers when a new vps is expected (headers should be given as out-of-band info)
      state.last_gof();
      if (state.cur_gof_has_unit(uvgV3CRTP::V3C_VPS) && num_nalus[uvgV3CRTP::V3C_VPS] > 0)
      {
        num_nalus[uvgV3CRTP::V3C_VPS] -= 1;
        if (num_nalus[uvgV3CRTP::V3C_VPS] != 0)
        {
          for (auto& unit_header : header_defs)
          {
            unit_header.vuh_v3c_parameter_set_id += 1;
          }
        }
      }
    }

    // Dont't stop receiving even if timestamp error occurs, just print the error
    if (state.get_error_flag() == uvgV3CRTP::ERROR_TYPE::TIMESTAMP) {
      std::cout << " Timestamp error: " << state.get_error_msg() << std::endl;
      state.reset_error_flag();
    }

    if (state.get_error_flag() == uvgV3CRTP::ERROR_TYPE::OK)
    {
      state.last_gof();
      std::cout << " Received:" << std::endl;
      state.print_cur_gof_bitstream_info();
    }
    else
    {
      std::cout << std::endl;
    }
    expected_number_of_gof -= 1;
  }

  std::cout << "Stopping receiving: " << state.get_error_msg() << std::endl;
  //
  // **************************************

  if (orig_available)
  {
    // Check that bitstream was correctly parsed
    compare_bitstreams(state, buf, length);
  }

  // ******** Print info about sample stream **********
  //
  // Print state and bitstream info
  state.print_state(false);

  //std::cout << "Bitstream info: " << std::endl;
  state.print_bitstream_info();

  //size_t len = 0;
  //auto info = std::unique_ptr<char, decltype(&free)>(state.get_bitstream_info_string(&len, uvgV3CRTP::INFO_FMT::PARAM), &free);
  //std::cout << info.get() << std::endl;
  //
  // **************************************

  return EXIT_SUCCESS;
}