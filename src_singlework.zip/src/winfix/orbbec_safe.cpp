#include "orbbec_safe.hpp"

bool orbbecSafePipelineStart(ob::Pipeline& pipeline, const std::shared_ptr<ob::Config>& config, bool enableFrameSync) {
    try {
        if (enableFrameSync) {
            pipeline.enableFrameSync();
        }
        pipeline.start(config);
        return true;
    } catch (...) {
        return false;
    }
}
