#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <deque>
#include <iostream>
#include <mutex>
#include <functional>
#include <optional>

#include "uvgutils/sync.hpp"
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include "uvgutils/utils.hpp"
#include "uvgvpcc/uvgvpcc.hpp"

using GeometryPoint = uvgutils::VectorN<uvgvpcc_enc::typeGeometryInput, 3>;
using AttributePoint = uvgutils::VectorN<uint8_t, 3>;

#if defined(ORBBEC_SDK_FOUND)
#include <algorithm>
#include <libobsensor/ObSensor.hpp>
#include "orbbec_safe.hpp"
#ifdef ERROR
#undef ERROR
#endif
#endif

/// Orbbec D2C-aligned RGB point cloud (Align + PointCloudFilter) for uvgVPCCenc.
struct PointCloudFrame {
    uint64_t frameNumber = 0;
    float origin[3]{0.F, 0.F, 0.F};
    float quantScale = 1.F;
    std::vector<GeometryPoint> geometry;
    std::vector<AttributePoint> attributes;
};

struct OrbbecCaptureConfig {
    // 640x480 keeps point counts manageable for live V-PCC on Windows.
    int colorWidth = 1280;
    int colorHeight = 720;
    int colorFps = 30;
    int depthWidth = 640;
    int depthHeight = 480;
    int depthFps = 30;
    size_t geoBitDepthInput = 9;
    size_t maxQueueDepth = 1;
    size_t maxPointsPerFrame = 500000;
    bool enableSyntheticFallback = true;
    /// Called on the capture thread when a new point cloud frame is ready (for live preview).
    std::function<void(const PointCloudFrame&)> onFrameCaptured;
};

class OrbbecCapture {
public:
    explicit OrbbecCapture(OrbbecCaptureConfig config = {})
        : config_(std::move(config)) {}

    ~OrbbecCapture() { stop(); }

    OrbbecCapture(const OrbbecCapture&) = delete;
    OrbbecCapture& operator=(const OrbbecCapture&) = delete;

#if defined(ORBBEC_SDK_FOUND)
    /// Probe for a camera on the main thread. Does not keep the device open (capture thread owns the pipeline).
    void prepareDevice() {
        std::cerr << "[orbbec] Querying devices...\n" << std::flush;
        ob::Context context;
        const auto deviceList = context.queryDeviceList();
        if (!deviceList || deviceList->getCount() == 0) {
            throw std::runtime_error(
                "No Orbbec camera found. Check USB, drivers, and close Orbbec Viewer if it is using the device.");
        }

        std::cerr << "[orbbec] Found " << deviceList->getCount() << " device(s)\n" << std::flush;
        if (auto device = deviceList->getDevice(0)) {
            if (auto info = device->getDeviceInfo()) {
                std::cerr << "[orbbec] Using device: " << info->name() << "\n" << std::flush;
            }
        }
    }
#endif

    void start(bool forceSynthetic = false) {
        if (running_.exchange(true)) {
            return;
        }

#if defined(ORBBEC_SDK_FOUND)
        if (forceSynthetic) {
            captureThread_ = std::jthread([this](std::stop_token stopToken) { captureLoopSynthetic(stopToken); });
        } else {
            captureThread_ = std::jthread([this](std::stop_token stopToken) { captureLoopOrbbec(stopToken); });
        }
#else
        if (!config_.enableSyntheticFallback) {
            running_ = false;
            throw std::runtime_error(
                "Orbbec SDK not found at configure time. Set ORBBEC_SDK_DIR or enable synthetic fallback.");
        }
        captureThread_ = std::jthread([this](std::stop_token stopToken) { captureLoopSynthetic(stopToken); });
#endif
    }

    void stop() {
        if (!running_.exchange(false)) {
            return;
        }
        if (captureThread_.joinable()) {
            captureThread_.request_stop();
            captureThread_.join();
        }
        {
            std::lock_guard lock(queueMutex_);
            queue_.clear();
        }
    }

    std::optional<PointCloudFrame> tryPopFrame() {
        std::lock_guard lock(queueMutex_);
        if (queue_.empty()) {
            return std::nullopt;
        }
        PointCloudFrame frame = std::move(queue_.front());
        queue_.pop_front();
        return frame;
    }

    std::optional<PointCloudFrame> waitPopFrame(std::chrono::milliseconds timeout) {
        const auto deadline = std::chrono::steady_clock::now() + timeout;
        while (running_.load()) {
            if (auto frame = tryPopFrame()) {
                return frame;
            }
            if (std::chrono::steady_clock::now() >= deadline) {
                return std::nullopt;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        return std::nullopt;
    }

    bool isRunning() const { return running_.load(); }

    bool captureFailed() const { return captureFailed_.load(); }

    std::optional<std::string> captureError() const {
        std::lock_guard lock(captureErrorMutex_);
        if (captureError_.empty()) {
            return std::nullopt;
        }
        return captureError_;
    }

private:
    void reportCaptureError(std::string message) {
        {
            std::lock_guard lock(captureErrorMutex_);
            captureError_ = std::move(message);
        }
        captureFailed_ = true;
        running_ = false;
        std::cerr << "[orbbec] ERROR: " << captureError_ << "\n" << std::flush;
    }
    static uvgvpcc_enc::typeGeometryInput quantizeCoord(float meters, float origin, float scale, size_t geoBitDepthInput) {
        const float qf = (meters - origin) * scale;
        const float maxValue = static_cast<float>((static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
        if (qf < 0.F || qf > maxValue) {
            return static_cast<uvgvpcc_enc::typeGeometryInput>(maxValue + 1U);
        }
        return static_cast<uvgvpcc_enc::typeGeometryInput>(qf);
    }

    static bool coordinateFitsVoxelGrid(const GeometryPoint& point, size_t geoBitDepthInput) {
        const auto maxValue = static_cast<uvgvpcc_enc::typeGeometryInput>(
            (static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
        return point[0] <= maxValue && point[1] <= maxValue && point[2] <= maxValue;
    }

    static uint8_t colorChannelToByte(float channel) {
        const float clamped = (std::max)(0.F, (std::min)(channel, 255.F));
        return static_cast<uint8_t>(clamped);
    }

    void pushFrame(PointCloudFrame frame) {
        if (config_.onFrameCaptured) {
            config_.onFrameCaptured(frame);
        }
        {
            std::lock_guard lock(queueMutex_);
            while (queue_.size() >= config_.maxQueueDepth) {
                queue_.pop_front();
            }
            queue_.push_back(std::move(frame));
        }
    }

#if defined(ORBBEC_SDK_FOUND)
    enum class OrbbecCaptureMode { RgbdD2c, DepthOnly };

    static void safePipelineStop(ob::Pipeline& pipeline) {
        try {
            pipeline.stop();
        } catch (...) {
        }
    }

    static const char* colorFormatName(OBFormat format) {
        switch (format) {
        case OB_FORMAT_RGB:
            return "RGB";
        case OB_FORMAT_MJPG:
            return "MJPG";
        default:
            return "unknown";
        }
    }

    void captureLoopOrbbec(std::stop_token stopToken) {
        try {
            captureLoopOrbbecImpl(stopToken);
        } catch (const ob::Error& error) {
            reportCaptureError(std::string("Orbbec SDK error: ") + error.getMessage());
        } catch (const std::exception& error) {
            reportCaptureError(error.what());
        } catch (...) {
            reportCaptureError("Unknown Orbbec capture failure");
        }
    }

    bool tryStartRgbdPipeline(
        std::shared_ptr<ob::Pipeline>& pipeline,
        OBFormat colorFormat,
        std::shared_ptr<ob::Align>& alignFilter,
        std::shared_ptr<ob::PointCloudFilter>& pointCloudFilter) {
        auto streamConfig = std::make_shared<ob::Config>();
        streamConfig->enableVideoStream(
            OB_STREAM_DEPTH, OB_WIDTH_ANY, OB_HEIGHT_ANY, OB_FPS_ANY, OB_FORMAT_ANY);
        streamConfig->enableVideoStream(
            OB_STREAM_COLOR, OB_WIDTH_ANY, OB_HEIGHT_ANY, OB_FPS_ANY, colorFormat);
        streamConfig->setFrameAggregateOutputMode(OB_FRAME_AGGREGATE_OUTPUT_ALL_TYPE_FRAME_REQUIRE);

        pipeline = std::make_shared<ob::Pipeline>();
        if (!orbbecSafePipelineStart(*pipeline, streamConfig, true)) {
            pipeline.reset();
            return false;
        }

        try {
            alignFilter = std::make_shared<ob::Align>(OB_STREAM_COLOR);
            pointCloudFilter = std::make_shared<ob::PointCloudFilter>();
            pointCloudFilter->setCreatePointFormat(OB_FORMAT_RGB_POINT);
        } catch (...) {
            pipeline->stop();
            pipeline.reset();
            return false;
        }
        return true;
    }

    bool tryStartDepthOnlyPipeline(
        std::shared_ptr<ob::Pipeline>& pipeline,
        std::shared_ptr<ob::PointCloudFilter>& pointCloudFilter) {
        auto streamConfig = std::make_shared<ob::Config>();
        streamConfig->enableVideoStream(
            OB_STREAM_DEPTH, OB_WIDTH_ANY, OB_HEIGHT_ANY, OB_FPS_ANY, OB_FORMAT_Y16);

        pipeline = std::make_shared<ob::Pipeline>();
        if (!orbbecSafePipelineStart(*pipeline, streamConfig)) {
            pipeline.reset();
            return false;
        }

        pointCloudFilter = std::make_shared<ob::PointCloudFilter>();
        pointCloudFilter->setCreatePointFormat(OB_FORMAT_POINT);
        return true;
    }

    void logOrbbecDevice(const std::shared_ptr<ob::Pipeline>& pipeline) {
        if (const auto device = pipeline->getDevice()) {
            if (const auto info = device->getDeviceInfo()) {
                std::cerr << "[orbbec] Device: " << info->name() << "\n" << std::flush;
            }
        }
    }

    void captureLoopOrbbecImpl(std::stop_token stopToken) {
        static constexpr float kMinDepthMm = 20.F;
        static constexpr float kMaxDepthMm = 3000.F;

        std::cerr << "[orbbec] Opening pipeline...\n" << std::flush;

        OrbbecCaptureMode mode = OrbbecCaptureMode::RgbdD2c;
        std::shared_ptr<ob::Pipeline> pipeline;
        std::shared_ptr<ob::Align> alignFilter;
        std::shared_ptr<ob::PointCloudFilter> pointCloudFilter;

        // Femto Bolt often needs MJPG; RGB can AV inside the SDK without throwing.
        const OBFormat colorFormats[] = {OB_FORMAT_MJPG, OB_FORMAT_RGB};
        bool started = false;
        for (const OBFormat colorFormat : colorFormats) {
            std::cerr << "[orbbec] Trying D2C RGBD (depth=ANY, color=" << colorFormatName(colorFormat) << ")...\n"
                      << std::flush;
            if (tryStartRgbdPipeline(pipeline, colorFormat, alignFilter, pointCloudFilter)) {
                std::cerr << "[orbbec] D2C RGBD active (depth=ANY, color=" << colorFormatName(colorFormat) << ")\n"
                          << std::flush;
                started = true;
                break;
            }
            std::cerr << "[orbbec] D2C " << colorFormatName(colorFormat) << " failed, trying next...\n" << std::flush;
        }

        if (!started) {
            std::cerr << "[orbbec] D2C RGBD unavailable, falling back to depth-only point cloud...\n" << std::flush;
            if (!tryStartDepthOnlyPipeline(pipeline, pointCloudFilter)) {
                throw std::runtime_error(
                    "Orbbec pipeline.start() failed for RGBD and depth-only modes (SDK access violation or device busy)");
            }
            mode = OrbbecCaptureMode::DepthOnly;
            std::cerr << "[orbbec] Depth-only pipeline active (OB_FORMAT_POINT, gray attributes)\n" << std::flush;
        }

        logOrbbecDevice(pipeline);

        for (int i = 0; i < 15 && !stopToken.stop_requested(); ++i) {
            pipeline->waitForFrameset(200);
        }

        uint64_t frameNumber = 0;
        float minX = 0.F;
        float minY = 0.F;
        float minZ = 0.F;
        float quantScale = 0.F;
        bool originInitialized = false;
        auto lastWaitLog = std::chrono::steady_clock::now();

        while (!stopToken.stop_requested() && running_) {
            auto frameSet = pipeline->waitForFrameset(1000);

            if (mode == OrbbecCaptureMode::RgbdD2c) {
                if (!frameSet || !frameSet->depthFrame() || !frameSet->colorFrame()) {
                    const auto now = std::chrono::steady_clock::now();
                    if (now - lastWaitLog >= std::chrono::seconds(5)) {
                        std::cerr << "[orbbec] Waiting for synchronized color+depth...\n" << std::flush;
                        lastWaitLog = now;
                    }
                    continue;
                }
            } else if (!frameSet || !frameSet->depthFrame()) {
                const auto now = std::chrono::steady_clock::now();
                if (now - lastWaitLog >= std::chrono::seconds(5)) {
                    std::cerr << "[orbbec] Waiting for depth frames...\n" << std::flush;
                    lastWaitLog = now;
                }
                continue;
            }
            lastWaitLog = std::chrono::steady_clock::now();

            std::shared_ptr<ob::Frame> cloudFrame;
            try {
                if (mode == OrbbecCaptureMode::RgbdD2c) {
                    auto alignedFrame = alignFilter->process(frameSet);
                    if (!alignedFrame) {
                        continue;
                    }
                    cloudFrame = pointCloudFilter->process(alignedFrame);
                } else {
                    cloudFrame = pointCloudFilter->process(frameSet->depthFrame());
                }
            } catch (const ob::Error& error) {
                std::cerr << "[orbbec] Filter failed: " << error.getMessage() << "\n" << std::flush;
                continue;
            }

            if (!cloudFrame) {
                continue;
            }

            PointCloudFrame frame;
            frame.frameNumber = frameNumber++;

            if (mode == OrbbecCaptureMode::RgbdD2c) {
                if (cloudFrame->format() != OB_FORMAT_RGB_POINT ||
                    cloudFrame->dataSize() < sizeof(OBColorPoint)) {
                    continue;
                }

                const auto* points = reinterpret_cast<const OBColorPoint*>(cloudFrame->data());
                const uint32_t pointCount = cloudFrame->dataSize() / static_cast<uint32_t>(sizeof(OBColorPoint));
                if (pointCount == 0) {
                    continue;
                }

                if (!originInitialized) {
                    float maxX = points[0].x;
                    float maxY = points[0].y;
                    float maxZ = points[0].z;
                    minX = points[0].x;
                    minY = points[0].y;
                    minZ = points[0].z;
                    for (uint32_t i = 1; i < pointCount; ++i) {
                        if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                            continue;
                        }
                        minX = (std::min)(minX, points[i].x);
                        minY = (std::min)(minY, points[i].y);
                        minZ = (std::min)(minZ, points[i].z);
                        maxX = (std::max)(maxX, points[i].x);
                        maxY = (std::max)(maxY, points[i].y);
                        maxZ = (std::max)(maxZ, points[i].z);
                    }
                    const float extentX = maxX - minX;
                    const float extentY = maxY - minY;
                    const float extentZ = maxZ - minZ;
                    const float maxExtent = (std::max)(extentX, (std::max)(extentY, extentZ));
                    const float maxVoxel =
                        static_cast<float>((static_cast<uint32_t>(1) << config_.geoBitDepthInput) - 1U);
                    quantScale = maxExtent > 1e-6F ? maxVoxel / maxExtent : 1.F;
                    originInitialized = true;
                    std::cerr << "[orbbec] D2C scene extent " << maxExtent << " mm, quant scale " << quantScale << "\n"
                              << std::flush;
                }

                const uint32_t stride =
                    (config_.maxPointsPerFrame > 0 && pointCount > config_.maxPointsPerFrame)
                        ? static_cast<uint32_t>((pointCount + config_.maxPointsPerFrame - 1) /
                                                config_.maxPointsPerFrame)
                        : 1U;
                const uint32_t reserveCount =
                    (std::min)(pointCount / stride, static_cast<uint32_t>(config_.maxPointsPerFrame));

                frame.origin[0] = minX;
                frame.origin[1] = minY;
                frame.origin[2] = minZ;
                frame.quantScale = quantScale;
                frame.geometry.reserve(reserveCount);
                frame.attributes.reserve(reserveCount);

                for (uint32_t i = 0; i < pointCount; i += stride) {
                    if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                        continue;
                    }

                    const auto qx = quantizeCoord(points[i].x, minX, quantScale, config_.geoBitDepthInput);
                    const auto qy = quantizeCoord(points[i].y, minY, quantScale, config_.geoBitDepthInput);
                    const auto qz = quantizeCoord(points[i].z, minZ, quantScale, config_.geoBitDepthInput);
                    const GeometryPoint geometry{qx, qy, qz};
                    if (!coordinateFitsVoxelGrid(geometry, config_.geoBitDepthInput)) {
                        continue;
                    }

                    frame.geometry.push_back(geometry);
                    frame.attributes.push_back(AttributePoint{
                        colorChannelToByte(points[i].r),
                        colorChannelToByte(points[i].g),
                        colorChannelToByte(points[i].b)});
                }

                if (frame.frameNumber == 0 && !frame.geometry.empty()) {
                    std::cerr << "[orbbec] First D2C cloud: raw=" << pointCount << " kept=" << frame.geometry.size()
                              << " stride=" << stride << "\n"
                              << std::flush;
                }
            } else {
                if (cloudFrame->format() != OB_FORMAT_POINT || cloudFrame->dataSize() < sizeof(OBPoint)) {
                    continue;
                }

                const auto* points = reinterpret_cast<const OBPoint*>(cloudFrame->data());
                const uint32_t pointCount = cloudFrame->dataSize() / static_cast<uint32_t>(sizeof(OBPoint));
                if (pointCount == 0) {
                    continue;
                }

                if (!originInitialized) {
                    float maxX = points[0].x;
                    float maxY = points[0].y;
                    float maxZ = points[0].z;
                    minX = points[0].x;
                    minY = points[0].y;
                    minZ = points[0].z;
                    for (uint32_t i = 1; i < pointCount; ++i) {
                        if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                            continue;
                        }
                        minX = (std::min)(minX, points[i].x);
                        minY = (std::min)(minY, points[i].y);
                        minZ = (std::min)(minZ, points[i].z);
                        maxX = (std::max)(maxX, points[i].x);
                        maxY = (std::max)(maxY, points[i].y);
                        maxZ = (std::max)(maxZ, points[i].z);
                    }
                    const float extentX = maxX - minX;
                    const float extentY = maxY - minY;
                    const float extentZ = maxZ - minZ;
                    const float maxExtent = (std::max)(extentX, (std::max)(extentY, extentZ));
                    const float maxVoxel =
                        static_cast<float>((static_cast<uint32_t>(1) << config_.geoBitDepthInput) - 1U);
                    quantScale = maxExtent > 1e-6F ? maxVoxel / maxExtent : 1.F;
                    originInitialized = true;
                    std::cerr << "[orbbec] Depth scene extent " << maxExtent << " mm, quant scale " << quantScale
                              << "\n"
                              << std::flush;
                }

                const uint32_t stride =
                    (config_.maxPointsPerFrame > 0 && pointCount > config_.maxPointsPerFrame)
                        ? static_cast<uint32_t>((pointCount + config_.maxPointsPerFrame - 1) /
                                                config_.maxPointsPerFrame)
                        : 1U;
                const uint32_t reserveCount =
                    (std::min)(pointCount / stride, static_cast<uint32_t>(config_.maxPointsPerFrame));

                frame.origin[0] = minX;
                frame.origin[1] = minY;
                frame.origin[2] = minZ;
                frame.quantScale = quantScale;
                frame.geometry.reserve(reserveCount);
                frame.attributes.reserve(reserveCount);

                for (uint32_t i = 0; i < pointCount; i += stride) {
                    if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                        continue;
                    }

                    const auto qx = quantizeCoord(points[i].x, minX, quantScale, config_.geoBitDepthInput);
                    const auto qy = quantizeCoord(points[i].y, minY, quantScale, config_.geoBitDepthInput);
                    const auto qz = quantizeCoord(points[i].z, minZ, quantScale, config_.geoBitDepthInput);
                    const GeometryPoint geometry{qx, qy, qz};
                    if (!coordinateFitsVoxelGrid(geometry, config_.geoBitDepthInput)) {
                        continue;
                    }

                    const uint8_t gray = static_cast<uint8_t>(
                        (std::max)(0.F, (std::min)(255.F, (points[i].z - kMinDepthMm) / (kMaxDepthMm - kMinDepthMm) * 255.F)));
                    frame.geometry.push_back(geometry);
                    frame.attributes.push_back(AttributePoint{gray, gray, gray});
                }

                if (frame.frameNumber == 0 && !frame.geometry.empty()) {
                    std::cerr << "[orbbec] First depth cloud: raw=" << pointCount << " kept=" << frame.geometry.size()
                              << " stride=" << stride << "\n"
                              << std::flush;
                }
            }

            if (frame.geometry.empty()) {
                continue;
            }
            pushFrame(std::move(frame));
        }

        safePipelineStop(*pipeline);
    }
#endif

    void captureLoopSynthetic(std::stop_token stopToken) {
        uint64_t frameNumber = 0;
        const float scale = static_cast<float>(1 << config_.geoBitDepthInput);

        while (!stopToken.stop_requested() && running_) {
            PointCloudFrame frame;
            frame.frameNumber = frameNumber++;
            frame.quantScale = 1.F;
            frame.geometry.reserve(4096);
            frame.attributes.reserve(4096);

            for (int y = 0; y < 64; ++y) {
                for (int x = 0; x < 64; ++x) {
                    const float xf = static_cast<float>(x) / 64.F;
                    const float yf = static_cast<float>(y) / 64.F;
                    const float zf = 0.35F + 0.15F * std::sin((xf + yf + frameNumber * 0.05F) * 6.2831853F);

                    const auto qx = static_cast<uvgvpcc_enc::typeGeometryInput>(xf * scale * 0.5F);
                    const auto qy = static_cast<uvgvpcc_enc::typeGeometryInput>(yf * scale * 0.5F);
                    const auto qz = static_cast<uvgvpcc_enc::typeGeometryInput>(zf * scale * 0.5F);
                    const GeometryPoint geometry{qx, qy, qz};
                    if (!coordinateFitsVoxelGrid(geometry, config_.geoBitDepthInput)) {
                        continue;
                    }

                    frame.geometry.push_back(geometry);
                    frame.attributes.push_back(AttributePoint{
                        static_cast<uint8_t>(xf * 255.F),
                        static_cast<uint8_t>(yf * 255.F),
                        static_cast<uint8_t>(128 + 127 * std::sin(xf * 6.2831853F)),
                    });
                }
            }

            pushFrame(std::move(frame));
            std::this_thread::sleep_for(std::chrono::milliseconds(1000 / (std::max)(1, config_.colorFps)));
        }
    }

    OrbbecCaptureConfig config_;
    std::atomic<bool> running_{false};
    std::atomic<bool> captureFailed_{false};
    mutable uvgutils::sync_mutex captureErrorMutex_;
    std::string captureError_;
    std::jthread captureThread_;
    uvgutils::sync_mutex queueMutex_;
    std::deque<PointCloudFrame> queue_;
};
