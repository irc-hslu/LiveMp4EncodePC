#pragma once

#include <memory>

#include <libobsensor/ObSensor.hpp>

/// Starts Orbbec pipeline; on Windows catches SDK access violations (0xc0000005).
bool orbbecSafePipelineStart(
    ob::Pipeline& pipeline,
    const std::shared_ptr<ob::Config>& config,
    bool enableFrameSync = false);
