#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

#include "OrbbecCapture.hpp"

namespace detail {

inline uvgvpcc_enc::typeGeometryInput quantizeCoord(
    float meters,
    float origin,
    float scale,
    size_t geoBitDepthInput) {
    const float qf = (meters - origin) * scale;
    const float maxValue = static_cast<float>((static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
    if (qf < 0.F || qf > maxValue) {
        return static_cast<uvgvpcc_enc::typeGeometryInput>(maxValue + 1U);
    }
    return static_cast<uvgvpcc_enc::typeGeometryInput>(qf);
}

inline bool coordinateFitsVoxelGrid(const GeometryPoint& point, size_t geoBitDepthInput) {
    const auto maxValue = static_cast<uvgvpcc_enc::typeGeometryInput>(
        (static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
    return point[0] <= maxValue && point[1] <= maxValue && point[2] <= maxValue;
}

}  // namespace detail

inline PointCloudFrame mergeWorldSlicesToFrame(
    const std::vector<WorldPointCloudSlice>& slices,
    uint64_t mergedFrameNumber,
    size_t geoBitDepthInput,
    size_t maxPointsPerFrame) {
    PointCloudFrame merged;
    merged.frameNumber = mergedFrameNumber;

    size_t totalPoints = 0;
    for (const auto& slice : slices) {
        totalPoints += slice.positionsMeters.size();
    }
    if (totalPoints == 0) {
        return merged;
    }

    const uint32_t stride =
        (maxPointsPerFrame > 0 && totalPoints > maxPointsPerFrame)
            ? static_cast<uint32_t>((totalPoints + maxPointsPerFrame - 1) / maxPointsPerFrame)
            : 1U;

    float minX = 0.F;
    float minY = 0.F;
    float minZ = 0.F;
    float maxX = 0.F;
    float maxY = 0.F;
    float maxZ = 0.F;
    bool boundsInitialized = false;

    for (const auto& slice : slices) {
        for (const auto& position : slice.positionsMeters) {
            if (!boundsInitialized) {
                minX = maxX = position[0];
                minY = maxY = position[1];
                minZ = maxZ = position[2];
                boundsInitialized = true;
            } else {
                minX = (std::min)(minX, position[0]);
                minY = (std::min)(minY, position[1]);
                minZ = (std::min)(minZ, position[2]);
                maxX = (std::max)(maxX, position[0]);
                maxY = (std::max)(maxY, position[1]);
                maxZ = (std::max)(maxZ, position[2]);
            }
        }
    }

    const float extentX = maxX - minX;
    const float extentY = maxY - minY;
    const float extentZ = maxZ - minZ;
    const float maxExtent = (std::max)(extentX, (std::max)(extentY, extentZ));
    const float maxVoxel = static_cast<float>((static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
    const float quantScale = maxExtent > 1e-6F ? maxVoxel / maxExtent : 1.F;

    merged.origin[0] = minX;
    merged.origin[1] = minY;
    merged.origin[2] = minZ;
    merged.quantScale = quantScale;

    const size_t reserveCount =
        (std::min)(totalPoints / stride + 1, maxPointsPerFrame > 0 ? maxPointsPerFrame : totalPoints);
    merged.geometry.reserve(reserveCount);
    merged.attributes.reserve(reserveCount);

    size_t globalIndex = 0;
    for (const auto& slice : slices) {
        for (size_t localIndex = 0; localIndex < slice.positionsMeters.size(); ++localIndex, ++globalIndex) {
            if (globalIndex % stride != 0) {
                continue;
            }
            const auto& position = slice.positionsMeters[localIndex];
            const auto qx = detail::quantizeCoord(position[0], minX, quantScale, geoBitDepthInput);
            const auto qy = detail::quantizeCoord(position[1], minY, quantScale, geoBitDepthInput);
            const auto qz = detail::quantizeCoord(position[2], minZ, quantScale, geoBitDepthInput);
            const GeometryPoint geometry{qx, qy, qz};
            if (!detail::coordinateFitsVoxelGrid(geometry, geoBitDepthInput)) {
                continue;
            }
            merged.geometry.push_back(geometry);
            merged.attributes.push_back(
                localIndex < slice.attributes.size() ? slice.attributes[localIndex] : AttributePoint{});
        }
    }

    return merged;
}
