#pragma once

#include <cstring>
#include <iostream>
#include <string>

/// Step-by-step tracing for multi-camera mode. Last [multi-debug] line before a crash
/// identifies the failing call site (file:line + step label).
namespace multiOrbbecDebug {

inline thread_local bool g_enabled = false;
inline thread_local const char* g_cameraSerial = "";
inline thread_local char g_lastStep[256] = {};

inline void setCameraContext(const char* serial) {
    g_cameraSerial = (serial != nullptr) ? serial : "";
    g_enabled = g_cameraSerial[0] != '\0';
}

inline void clearCameraContext() {
    g_enabled = false;
    g_cameraSerial = "";
    g_lastStep[0] = '\0';
}

inline void log(const char* component, const char* file, int line, const char* step) {
    if (!g_enabled && std::strcmp(component, "main") != 0 && std::strcmp(component, "multi") != 0) {
        return;
    }
    const char* serial = (g_cameraSerial != nullptr && g_cameraSerial[0] != '\0') ? g_cameraSerial : "-";
    std::string message = std::string(component) + " | " + step;
    if (message.size() >= sizeof(g_lastStep)) {
        message.resize(sizeof(g_lastStep) - 1);
    }
    std::memcpy(g_lastStep, message.c_str(), message.size() + 1);
    std::cerr << "[multi-debug][" << serial << "][" << component << "] "
              << file << ":" << line << " " << step << "\n"
              << std::flush;
}

inline void logMain(const char* file, int line, const char* step) {
    log("main", file, line, step);
}

inline void logMain(const char* file, int line, const std::string& step) {
    logMain(file, line, step.c_str());
}

inline void logMulti(const char* file, int line, const char* step) {
    log("multi", file, line, step);
}

inline void logOrbbec(const char* file, int line, const char* step) {
    if (!g_enabled) {
        return;
    }
    log("orbbec", file, line, step);
}

inline void logOrbbec(const char* file, int line, const std::string& step) {
    logOrbbec(file, line, step.c_str());
}

inline void logMulti(const char* file, int line, const std::string& step) {
    logMulti(file, line, step.c_str());
}

inline void logSafe(const char* file, int line, const char* step) {
    if (!g_enabled) {
        return;
    }
    log("orbbec_safe", file, line, step);
}

inline void logLastStepOnError(const char* component) {
    if (g_lastStep[0] == '\0') {
        return;
    }
    const char* serial = (g_cameraSerial != nullptr && g_cameraSerial[0] != '\0') ? g_cameraSerial : "-";
    std::cerr << "[multi-debug][" << serial << "][" << component << "] LAST_STEP=" << g_lastStep << "\n"
              << std::flush;
}

}  // namespace multiOrbbecDebug

#define MULTI_DEBUG_ORBBEC(step) multiOrbbecDebug::logOrbbec(__FILE__, __LINE__, step)
#define MULTI_DEBUG_ORBBEC_STR(step) multiOrbbecDebug::logOrbbec(__FILE__, __LINE__, step)
#define MULTI_DEBUG_SAFE(step) multiOrbbecDebug::logSafe(__FILE__, __LINE__, step)
#define MULTI_DEBUG_MULTI(step) multiOrbbecDebug::logMulti(__FILE__, __LINE__, step)
#define MULTI_DEBUG_MULTI_STR(step) multiOrbbecDebug::logMulti(__FILE__, __LINE__, step)
#define MULTI_DEBUG_MAIN(step) multiOrbbecDebug::logMain(__FILE__, __LINE__, step)

#define MULTI_DEBUG_MAIN_STR(step) multiOrbbecDebug::logMain(__FILE__, __LINE__, step)
