#include "orbbec_safe.hpp"

#include "multi_orbbec_debug.hpp"

#include <chrono>
#include <iostream>
#include <mutex>
#include <thread>

namespace {

template <typename Fn>
auto orbbecSafeCall(Fn&& fn, auto fallback) {
    try {
        return fn();
    } catch (...) {
        return fallback;
    }
}

template <typename Fn>
void orbbecSafeCallVoid(Fn&& fn) {
    try {
        fn();
    } catch (...) {
    }
}

const char* formatName(OBFormat format) {
    switch (format) {
    case OB_FORMAT_RGB:
        return "RGB";
    case OB_FORMAT_MJPG:
        return "MJPG";
    case OB_FORMAT_Y16:
        return "Y16";
    default:
        return "unknown";
    }
}

void logVideoProfile(const char* label, const std::shared_ptr<ob::StreamProfile>& profile) {
    if (!profile) {
        std::cerr << "[orbbec] " << label << ": (null)\n" << std::flush;
        return;
    }
    try {
        const auto video = profile->as<ob::VideoStreamProfile>();
        std::cerr << "[orbbec] " << label << ": " << video->width() << "x" << video->height() << " @ "
                  << video->fps() << "fps " << formatName(video->format()) << "\n"
                  << std::flush;
    } catch (...) {
        std::cerr << "[orbbec] " << label << ": (profile)\n" << std::flush;
    }
}

/// Femto Bolt native color: 1920x1080 MJPG @ 30fps (see OrbbecSDKConfig.xml).
std::shared_ptr<ob::StreamProfile> pickMjpg1080p30(ob::Pipeline& pipeline) {
    const auto colorProfiles = pipeline.getStreamProfileList(OB_SENSOR_COLOR);
    if (!colorProfiles || colorProfiles->count() == 0) {
        return nullptr;
    }

    const struct {
        int width;
        int height;
        int fps;
    } candidates[] = {
        {1920, 1080, 30},
        {1920, 1080, OB_FPS_ANY},
        {1280, 720, 30},
        {OB_WIDTH_ANY, OB_HEIGHT_ANY, OB_FPS_ANY},
    };

    for (const auto& candidate : candidates) {
        try {
            auto profile =
                colorProfiles->getVideoStreamProfile(candidate.width, candidate.height, OB_FORMAT_MJPG, candidate.fps);
            if (profile) {
                return profile;
            }
        } catch (...) {
        }
    }

    try {
        return colorProfiles->getProfile(OB_PROFILE_DEFAULT);
    } catch (...) {
        return nullptr;
    }
}

/// Depth profile without getD2CDepthProfileList (that API starts the color decoder and can exhaust Win MFT).
std::shared_ptr<ob::StreamProfile> pickStandaloneDepthProfile(ob::Pipeline& pipeline, uint32_t preferredFps) {
    const auto depthProfiles = pipeline.getStreamProfileList(OB_SENSOR_DEPTH);
    if (!depthProfiles || depthProfiles->count() == 0) {
        return nullptr;
    }

    const struct {
        int width;
        int height;
        int fps;
    } candidates[] = {
        {640, 576, static_cast<int>(preferredFps)},
        {640, 576, 30},
        {640, 576, OB_FPS_ANY},
        {640, 480, static_cast<int>(preferredFps)},
        {OB_WIDTH_ANY, OB_HEIGHT_ANY, OB_FPS_ANY},
    };

    for (const auto& candidate : candidates) {
        try {
            auto profile = depthProfiles->getVideoStreamProfile(
                candidate.width, candidate.height, OB_FORMAT_Y16, candidate.fps);
            if (profile) {
                return profile;
            }
        } catch (...) {
        }
    }

    try {
        return depthProfiles->getProfile(OB_PROFILE_DEFAULT);
    } catch (...) {
        return nullptr;
    }
}

uint32_t profileFps(const std::shared_ptr<ob::StreamProfile>& profile, uint32_t fallbackFps) {
    if (!profile) {
        return fallbackFps;
    }
    try {
        return profile->as<ob::VideoStreamProfile>()->fps();
    } catch (...) {
        return fallbackFps;
    }
}

bool startRgbdStreamsOnPipeline(ob::Pipeline& pipeline, bool multiCameraLabel) {
    if (multiCameraLabel) {
        auto streamConfig = std::make_shared<ob::Config>();
        streamConfig->enableVideoStream(OB_STREAM_DEPTH);
        streamConfig->enableVideoStream(OB_STREAM_COLOR, 1280, 720, 15, OB_FORMAT_MJPG);
        streamConfig->setFrameAggregateOutputMode(OB_FRAME_AGGREGATE_OUTPUT_ANY_SITUATION);
        try {
            pipeline.start(streamConfig);
            try {
                pipeline.enableFrameSync();
            } catch (...) {
            }
            std::cerr << "[orbbec] Multi-camera streams: depth + 1280x720 MJPG (ANY_SITUATION)\n" << std::flush;
            return true;
        } catch (...) {
            std::cerr << "[orbbec] pipeline.start() failed (multi-camera)\n" << std::flush;
            return false;
        }
    }

    const auto colorProfile = pickMjpg1080p30(pipeline);
    if (!colorProfile) {
        std::cerr << "[orbbec] No 1920x1080 MJPG color profile found"
                  << (multiCameraLabel ? " (multi-camera)\n" : "\n")
                  << std::flush;
        return false;
    }

    const uint32_t colorFps = profileFps(colorProfile, 30U);
    const auto depthProfile = pickStandaloneDepthProfile(pipeline, colorFps);
    if (!depthProfile) {
        std::cerr << "[orbbec] No depth stream profile found"
                  << (multiCameraLabel ? " (multi-camera)\n" : "\n")
                  << std::flush;
        return false;
    }

    logVideoProfile("Color profile", colorProfile);
    logVideoProfile("Depth profile", depthProfile);
    std::cerr << "[orbbec] D2C via software Align filter"
              << (multiCameraLabel ? " (multi-camera)\n" : "\n")
              << std::flush;

    auto streamConfig = std::make_shared<ob::Config>();
    streamConfig->enableStream(colorProfile);
    streamConfig->enableStream(depthProfile);
    streamConfig->setFrameAggregateOutputMode(OB_FRAME_AGGREGATE_OUTPUT_ALL_TYPE_FRAME_REQUIRE);

    try {
        pipeline.start(streamConfig);
        return true;
    } catch (...) {
        std::cerr << "[orbbec] pipeline.start() failed"
                  << (multiCameraLabel ? " (multi-camera)\n" : " (close Orbbec Viewer; unplug extra cameras)\n")
                  << std::flush;
        return false;
    }
}

}  // namespace

void orbbecPipelineReleaseCooldown() {
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
}

std::recursive_mutex& orbbecSdkMutex() {
    static std::recursive_mutex mutex;
    return mutex;
}

std::shared_ptr<ob::Context>& orbbecSharedContext() {
    static std::shared_ptr<ob::Context> context;
    return context;
}

void orbbecEnsureSharedContext() {
    if (!orbbecSharedContext()) {
        orbbecSharedContext() = std::make_shared<ob::Context>();
    }
}

uint32_t orbbecSafeGetDeviceCount() {
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    const auto query = orbbecSafeQueryDevices();
    if (!query.deviceList) {
        return 0;
    }
    return query.deviceList->getCount();
}

OrbbecDeviceQuery orbbecSafeQueryDevices() {
    return orbbecSafeCall(
        []() -> OrbbecDeviceQuery {
            std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
            orbbecEnsureSharedContext();
            OrbbecDeviceQuery query;
            query.context = orbbecSharedContext();
            query.deviceList = query.context->queryDeviceList();
            return query;
        },
        OrbbecDeviceQuery{});
}

bool orbbecSafeIsSerialConnected(const std::string& serial) {
    return orbbecSafeCall(
        [&serial]() -> bool {
            std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
            orbbecEnsureSharedContext();
            const auto deviceList = orbbecSharedContext()->queryDeviceList();
            if (!deviceList || deviceList->getCount() == 0) {
                return false;
            }
            if (serial.empty()) {
                return true;
            }
            return orbbecSafeFindDeviceBySerial(*deviceList, serial) != nullptr;
        },
        false);
}

std::shared_ptr<ob::Device> orbbecSafeGetDefaultDevice() {
    return orbbecSafeCall(
        []() -> std::shared_ptr<ob::Device> {
            std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
            orbbecEnsureSharedContext();
            const auto deviceList = orbbecSharedContext()->queryDeviceList();
            if (!deviceList || deviceList->getCount() == 0) {
                return nullptr;
            }
            return deviceList->getDevice(0);
        },
        std::shared_ptr<ob::Device>{});
}

std::shared_ptr<ob::Device> orbbecSafeFindDeviceBySerial(ob::DeviceList& deviceList, const std::string& serial) {
    if (serial.empty()) {
        return nullptr;
    }

    return orbbecSafeCall(
        [&deviceList, &serial]() -> std::shared_ptr<ob::Device> {
            const uint32_t count = deviceList.getCount();
            for (uint32_t index = 0; index < count; ++index) {
                auto device = deviceList.getDevice(index);
                if (!device) {
                    continue;
                }
                const auto info = device->getDeviceInfo();
                if (!info) {
                    continue;
                }
                const char* deviceSerial = info->serialNumber();
                if (!deviceSerial) {
                    continue;
                }
                if (serial == deviceSerial) {
                    return device;
                }
            }
            return nullptr;
        },
        std::shared_ptr<ob::Device>{});
}

bool orbbecSafePipelineStart(ob::Pipeline& pipeline, const std::shared_ptr<ob::Config>& config, bool enableFrameSync) {
    return orbbecSafeCall(
        [&]() -> bool {
            if (enableFrameSync) {
                try {
                    pipeline.enableFrameSync();
                } catch (...) {
                }
            }
            pipeline.start(config);
            return true;
        },
        false);
}

bool orbbecSafeTryStartRgbdPipeline(
    const std::shared_ptr<ob::Device>& device,
    OBFormat colorFormat,
    OrbbecRgbdPipelineHandles& out,
    bool multiCameraReducedResolution) {
    MULTI_DEBUG_SAFE("orbbecSafeTryStartRgbdPipeline:enter");
    if (colorFormat != OB_FORMAT_MJPG) {
        std::cerr << "[orbbec] Skipping color format " << formatName(colorFormat)
                  << " (Femto Bolt uses 1920x1080 MJPG @ 30fps)\n"
                  << std::flush;
        return false;
    }

    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    out.pipeline.reset();
    out.alignFilter.reset();
    out.pointCloudFilter.reset();

    const bool started = orbbecSafeCall(
        [&]() -> bool {
            MULTI_DEBUG_SAFE("create Pipeline:before");
            if (multiCameraReducedResolution) {
                std::cerr << "[orbbec] Creating pipeline (1280x720 MJPG multi-camera + depth)...\n" << std::flush;
            } else {
                std::cerr << "[orbbec] Creating pipeline (1920x1080 MJPG + depth, software Align)...\n" << std::flush;
            }
            out.pipeline = device ? std::make_shared<ob::Pipeline>(device) : std::make_shared<ob::Pipeline>();
            MULTI_DEBUG_SAFE("create Pipeline:after");

            MULTI_DEBUG_SAFE("startRgbdStreamsOnPipeline:before");
            if (!startRgbdStreamsOnPipeline(*out.pipeline, multiCameraReducedResolution)) {
                return false;
            }
            MULTI_DEBUG_SAFE("startRgbdStreamsOnPipeline:after");

            MULTI_DEBUG_SAFE("create Align:before");
            out.alignFilter = std::make_shared<ob::Align>(OB_STREAM_COLOR);
            MULTI_DEBUG_SAFE("create PointCloudFilter:before");
            out.pointCloudFilter = std::make_shared<ob::PointCloudFilter>();
            out.pointCloudFilter->setCreatePointFormat(OB_FORMAT_RGB_POINT);
            MULTI_DEBUG_SAFE("create filters:after");
            return true;
        },
        false);

    if (!started && out.pipeline) {
        orbbecSafePipelineStop(*out.pipeline);
        out.pipeline.reset();
        out.alignFilter.reset();
        out.pointCloudFilter.reset();
        orbbecPipelineReleaseCooldown();
    }
    MULTI_DEBUG_SAFE("orbbecSafeTryStartRgbdPipeline:exit");
    return started;
}

bool orbbecSafeTryStartDepthOnlyPipeline(
    const std::shared_ptr<ob::Device>& device,
    std::shared_ptr<ob::Pipeline>& pipeline,
    std::shared_ptr<ob::PointCloudFilter>& pointCloudFilter) {
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    pipeline.reset();
    pointCloudFilter.reset();

    const bool started = orbbecSafeCall(
        [&]() -> bool {
            pipeline = device ? std::make_shared<ob::Pipeline>(device) : std::make_shared<ob::Pipeline>();

            const auto depthProfile = pickStandaloneDepthProfile(*pipeline, 30U);
            if (!depthProfile) {
                std::cerr << "[orbbec] No depth stream profile available\n" << std::flush;
                return false;
            }
            logVideoProfile("Depth-only profile", depthProfile);

            auto streamConfig = std::make_shared<ob::Config>();
            streamConfig->enableStream(depthProfile);
            streamConfig->setFrameAggregateOutputMode(OB_FRAME_AGGREGATE_OUTPUT_ALL_TYPE_FRAME_REQUIRE);

            if (!orbbecSafePipelineStart(*pipeline, streamConfig, false)) {
                std::cerr << "[orbbec] Depth-only pipeline.start() failed\n" << std::flush;
                orbbecSafePipelineStop(*pipeline);
                pipeline.reset();
                orbbecPipelineReleaseCooldown();
                return false;
            }

            pointCloudFilter = std::make_shared<ob::PointCloudFilter>();
            pointCloudFilter->setCreatePointFormat(OB_FORMAT_POINT);
            return true;
        },
        false);

    if (!started && pipeline) {
        orbbecSafePipelineStop(*pipeline);
        pipeline.reset();
        orbbecPipelineReleaseCooldown();
    }
    return started;
}

std::shared_ptr<ob::FrameSet> orbbecSafeWaitForFrameset(ob::Pipeline& pipeline, uint32_t timeoutMs) {
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    return orbbecSafeCall(
        [&]() -> std::shared_ptr<ob::FrameSet> { return pipeline.waitForFrameset(timeoutMs); },
        std::shared_ptr<ob::FrameSet>{});
}

std::shared_ptr<ob::Frame> orbbecSafeProcessRgbdPointCloud(
    ob::Align& alignFilter,
    ob::PointCloudFilter& pointCloudFilter,
    const std::shared_ptr<ob::FrameSet>& frameSet) {
    if (!frameSet) {
        return nullptr;
    }
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    MULTI_DEBUG_SAFE("orbbecSafeProcessRgbdPointCloud:enter");
    auto cloud = orbbecSafeCall(
        [&]() -> std::shared_ptr<ob::Frame> {
            auto alignedFrame = alignFilter.process(frameSet);
            if (!alignedFrame) {
                return nullptr;
            }
            return pointCloudFilter.process(alignedFrame);
        },
        std::shared_ptr<ob::Frame>{});
    MULTI_DEBUG_SAFE("orbbecSafeProcessRgbdPointCloud:exit");
    return cloud;
}

std::shared_ptr<ob::Frame> orbbecSafeProcessFrameSetPointCloud(
    ob::PointCloudFilter& pointCloudFilter,
    const std::shared_ptr<ob::FrameSet>& frameSet) {
    if (!frameSet) {
        return nullptr;
    }
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    return orbbecSafeCall(
        [&]() -> std::shared_ptr<ob::Frame> { return pointCloudFilter.process(frameSet); },
        std::shared_ptr<ob::Frame>{});
}

std::shared_ptr<ob::Frame> orbbecSafeProcessDepthPointCloud(
    ob::PointCloudFilter& pointCloudFilter,
    const std::shared_ptr<ob::DepthFrame>& depthFrame) {
    if (!depthFrame) {
        return nullptr;
    }
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    return orbbecSafeCall(
        [&]() -> std::shared_ptr<ob::Frame> { return pointCloudFilter.process(depthFrame); },
        std::shared_ptr<ob::Frame>{});
}

void orbbecSafePipelineStop(ob::Pipeline& pipeline) {
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    orbbecSafeCallVoid([&]() { pipeline.stop(); });
}

void orbbecSafeLogDeviceLabel(const std::shared_ptr<ob::Device>& device, const std::string& serial) {
    orbbecSafeCallVoid([&]() {
        if (!device) {
            std::cerr << "[orbbec] Opening " << serial << " (device null)\n" << std::flush;
            return;
        }
        if (const auto info = device->getDeviceInfo()) {
            std::cerr << "[orbbec] Opening " << serial << " (" << info->name() << ")\n" << std::flush;
        } else {
            std::cerr << "[orbbec] Opening " << serial << "\n" << std::flush;
        }
    });
}

std::vector<std::shared_ptr<ob::Device>> orbbecSafeBindDevicesBySerial(
    ob::DeviceList& deviceList,
    const std::vector<std::string>& serialsInOrder) {
    return orbbecSafeCall(
        [&]() -> std::vector<std::shared_ptr<ob::Device>> {
            std::vector<std::shared_ptr<ob::Device>> bound;
            bound.reserve(serialsInOrder.size());

            for (const auto& serial : serialsInOrder) {
                std::shared_ptr<ob::Device> device = orbbecSafeFindDeviceBySerial(deviceList, serial);
                if (!device) {
                    std::cerr << "[orbbec] Device not found for serial: " << serial << "\n" << std::flush;
                    return {};
                }
                bound.push_back(std::move(device));
            }
            return bound;
        },
        std::vector<std::shared_ptr<ob::Device>>{});
}

std::shared_ptr<ob::Pipeline> orbbecSafeCreatePipeline(const std::shared_ptr<ob::Device>& device) {
    if (!device) {
        return nullptr;
    }
    return orbbecSafeCall(
        [&]() -> std::shared_ptr<ob::Pipeline> { return std::make_shared<ob::Pipeline>(device); },
        std::shared_ptr<ob::Pipeline>{});
}

bool orbbecSafeStartRgbdOnPipeline(ob::Pipeline& pipeline, OrbbecRgbdPipelineHandles& out) {
    out.alignFilter.reset();
    out.pointCloudFilter.reset();

    const bool started = orbbecSafeCall(
        [&]() -> bool {
            if (!startRgbdStreamsOnPipeline(pipeline, true)) {
                return false;
            }
            out.alignFilter = std::make_shared<ob::Align>(OB_STREAM_COLOR);
            out.pointCloudFilter = std::make_shared<ob::PointCloudFilter>();
            out.pointCloudFilter->setCreatePointFormat(OB_FORMAT_RGB_POINT);
            return true;
        },
        false);

    if (!started) {
        orbbecSafePipelineStop(pipeline);
        orbbecPipelineReleaseCooldown();
    }
    return started;
}

std::shared_ptr<ob::Device> orbbecSafeBindDeviceBySerial(ob::DeviceList& deviceList, const std::string& serial) {
    if (serial.empty()) {
        return nullptr;
    }
    std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
    return orbbecSafeCall(
        [&deviceList, &serial]() -> std::shared_ptr<ob::Device> {
            try {
                auto device = deviceList.getDeviceBySN(serial.c_str());
                if (device) {
                    return device;
                }
            } catch (...) {
            }
            return orbbecSafeFindDeviceBySerial(deviceList, serial);
        },
        std::shared_ptr<ob::Device>{});
}

bool orbbecSafeOpenDeviceBySerial(
    const std::string& serial,
    std::shared_ptr<ob::Context>& outContext,
    std::shared_ptr<ob::Device>& outDevice) {
    outContext.reset();
    outDevice.reset();
    if (serial.empty()) {
        return false;
    }
    return orbbecSafeCall(
        [&]() -> bool {
            std::lock_guard<std::recursive_mutex> sdkLock(orbbecSdkMutex());
            outContext = std::make_shared<ob::Context>();
            const auto deviceList = outContext->queryDeviceList();
            if (!deviceList || deviceList->getCount() == 0) {
                return false;
            }
            outDevice = orbbecSafeBindDeviceBySerial(*deviceList, serial);
            if (!outDevice) {
                outContext.reset();
                return false;
            }
            orbbecSafeLogDeviceLabel(outDevice, serial);
            return true;
        },
        false);
}
