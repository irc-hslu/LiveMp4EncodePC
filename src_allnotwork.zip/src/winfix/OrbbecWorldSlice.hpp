#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>

#include "CameraConfig.hpp"
#include "OrbbecCapture.hpp"

#if defined(ORBBEC_SDK_FOUND)
#include <libobsensor/ObSensor.hpp>
#endif

inline constexpr float kOrbbecMinDepthMm = 20.F;
inline constexpr float kOrbbecMaxDepthMm = 3000.F;

#if defined(ORBBEC_SDK_FOUND)

inline uint8_t orbbecColorChannelToByte(float channel) {
    const float clamped = (std::max)(0.F, (std::min)(channel, 255.F));
    return static_cast<uint8_t>(clamped);
}

inline WorldPointCloudSlice buildWorldSliceFromRgbPoints(
    uint64_t frameNumber,
    const OBColorPoint* points,
    uint32_t pointCount,
    uint32_t stride,
    size_t maxPointsPerFrame,
    bool hasWorldTransform,
    const std::array<float, 16>& worldTransform,
    float oxMm,
    float oyMm,
    float ozMm) {
    WorldPointCloudSlice slice;
    slice.frameNumber = frameNumber;
    const uint32_t reserveCount =
        (std::min)(pointCount / stride, static_cast<uint32_t>(maxPointsPerFrame));
    slice.positionsMeters.reserve(reserveCount);
    slice.attributes.reserve(reserveCount);

    for (uint32_t i = 0; i < pointCount; i += stride) {
        if (points[i].z < kOrbbecMinDepthMm || points[i].z > kOrbbecMaxDepthMm) {
            continue;
        }

        float xWorld = 0.F;
        float yWorld = 0.F;
        float zWorld = 0.F;
        if (hasWorldTransform) {
            transformOrbbecPointToWorld(
                points[i].x, points[i].y, points[i].z, worldTransform, oxMm, oyMm, ozMm, xWorld, yWorld, zWorld);
        } else {
            xWorld = points[i].x / kMmPerMeter;
            yWorld = points[i].y / kMmPerMeter;
            zWorld = points[i].z / kMmPerMeter;
        }

        slice.positionsMeters.push_back({xWorld, yWorld, zWorld});
        slice.attributes.push_back(AttributePoint{
            orbbecColorChannelToByte(points[i].r),
            orbbecColorChannelToByte(points[i].g),
            orbbecColorChannelToByte(points[i].b)});
    }

    return slice;
}

inline WorldPointCloudSlice buildWorldSliceFromDepthPoints(
    uint64_t frameNumber,
    const OBPoint* points,
    uint32_t pointCount,
    uint32_t stride,
    size_t maxPointsPerFrame,
    bool hasWorldTransform,
    const std::array<float, 16>& worldTransform,
    float oxMm,
    float oyMm,
    float ozMm) {
    WorldPointCloudSlice slice;
    slice.frameNumber = frameNumber;
    const uint32_t reserveCount =
        (std::min)(pointCount / stride, static_cast<uint32_t>(maxPointsPerFrame));
    slice.positionsMeters.reserve(reserveCount);
    slice.attributes.reserve(reserveCount);

    for (uint32_t i = 0; i < pointCount; i += stride) {
        if (points[i].z < kOrbbecMinDepthMm || points[i].z > kOrbbecMaxDepthMm) {
            continue;
        }

        float xWorld = 0.F;
        float yWorld = 0.F;
        float zWorld = 0.F;
        if (hasWorldTransform) {
            transformOrbbecPointToWorld(
                points[i].x, points[i].y, points[i].z, worldTransform, oxMm, oyMm, ozMm, xWorld, yWorld, zWorld);
        } else {
            xWorld = points[i].x / kMmPerMeter;
            yWorld = points[i].y / kMmPerMeter;
            zWorld = points[i].z / kMmPerMeter;
        }

        const uint8_t gray = static_cast<uint8_t>((std::max)(
            0.F,
            (std::min)(255.F, (points[i].z - kOrbbecMinDepthMm) / (kOrbbecMaxDepthMm - kOrbbecMinDepthMm) * 255.F)));
        slice.positionsMeters.push_back({xWorld, yWorld, zWorld});
        slice.attributes.push_back(AttributePoint{gray, gray, gray});
    }

    return slice;
}

#endif  // ORBBEC_SDK_FOUND
