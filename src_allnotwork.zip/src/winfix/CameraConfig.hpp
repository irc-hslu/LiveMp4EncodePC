#pragma once

#include <array>
#include <cctype>
#include <cmath>
#include <fstream>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

/// One camera entry from cameraconfig.json (plylivestream-webrtc format).
struct CameraConfigEntry {
    std::string serial;
    std::array<float, 16> trafo{};
    bool hasTrafo = false;
    /// Layout offset from JSON in millimeters (converted to meters when applying).
    float oxMm = 0.F;
    float oyMm = 0.F;
    float ozMm = 0.F;
};

inline constexpr float kMmPerMeter = 1000.F;

/// p' = M * p with M stored column-major (OpenGL / cameraconfig.json). Input/output in meters.
inline void transformPointColumnMajor(
    const std::array<float, 16>& matrix,
    float x,
    float y,
    float z,
    float& xOut,
    float& yOut,
    float& zOut) {
    xOut = matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12];
    yOut = matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13];
    zOut = matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14];
}

/// Orbbec point (mm) → world meters using cameraconfig trafo + layout offset (mm → m).
inline void transformOrbbecPointToWorld(
    float xMm,
    float yMm,
    float zMm,
    const std::array<float, 16>& matrix,
    float oxMm,
    float oyMm,
    float ozMm,
    float& xWorldM,
    float& yWorldM,
    float& zWorldM) {
    const float xM = xMm / kMmPerMeter;
    const float yM = yMm / kMmPerMeter;
    const float zM = zMm / kMmPerMeter;
    transformPointColumnMajor(matrix, xM, yM, zM, xWorldM, yWorldM, zWorldM);
    xWorldM += oxMm / kMmPerMeter;
    yWorldM += oyMm / kMmPerMeter;
    zWorldM += ozMm / kMmPerMeter;
}

namespace detail {

inline void skipWs(const std::string& text, size_t& i) {
    while (i < text.size() && std::isspace(static_cast<unsigned char>(text[i])) != 0) {
        ++i;
    }
}

inline bool matchLiteral(const std::string& text, size_t& i, char literal) {
    skipWs(text, i);
    if (i >= text.size() || text[i] != literal) {
        return false;
    }
    ++i;
    return true;
}

inline std::optional<std::string> parseJsonString(const std::string& text, size_t& i) {
    skipWs(text, i);
    if (i >= text.size() || text[i] != '"') {
        return std::nullopt;
    }
    ++i;
    std::string out;
    while (i < text.size()) {
        const char c = text[i++];
        if (c == '"') {
            return out;
        }
        if (c == '\\' && i < text.size()) {
            out.push_back(text[i++]);
        } else {
            out.push_back(c);
        }
    }
    return std::nullopt;
}

inline std::optional<double> parseJsonNumber(const std::string& text, size_t& i) {
    skipWs(text, i);
    const size_t start = i;
    while (i < text.size()) {
        const char c = text[i];
        if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') {
            ++i;
        } else {
            break;
        }
    }
    if (start == i) {
        return std::nullopt;
    }
    try {
        return std::stod(text.substr(start, i - start));
    } catch (...) {
        return std::nullopt;
    }
}

inline void skipValue(const std::string& text, size_t& i) {
    skipWs(text, i);
    if (i >= text.size()) {
        return;
    }
    if (text[i] == '"') {
        parseJsonString(text, i);
        return;
    }
    if (text[i] == '{') {
        if (!matchLiteral(text, i, '{')) {
            return;
        }
        while (i < text.size()) {
            skipWs(text, i);
            if (i < text.size() && text[i] == '}') {
                ++i;
                return;
            }
            parseJsonString(text, i);
            if (!matchLiteral(text, i, ':')) {
                return;
            }
            skipValue(text, i);
            skipWs(text, i);
            if (i < text.size() && text[i] == ',') {
                ++i;
                continue;
            }
            if (i < text.size() && text[i] == '}') {
                ++i;
                return;
            }
        }
        return;
    }
    if (text[i] == '[') {
        if (!matchLiteral(text, i, '[')) {
            return;
        }
        while (i < text.size()) {
            skipWs(text, i);
            if (i < text.size() && text[i] == ']') {
                ++i;
                return;
            }
            skipValue(text, i);
            skipWs(text, i);
            if (i < text.size() && text[i] == ',') {
                ++i;
                continue;
            }
            if (i < text.size() && text[i] == ']') {
                ++i;
                return;
            }
        }
        return;
    }
    parseJsonNumber(text, i);
}

inline std::optional<std::array<float, 16>> parseTrafoArray(const std::string& text, size_t& i) {
    skipWs(text, i);
    if (!matchLiteral(text, i, '[')) {
        return std::nullopt;
    }
    std::array<float, 16> values{};
    size_t count = 0;
    while (i < text.size()) {
        skipWs(text, i);
        if (i < text.size() && text[i] == ']') {
            ++i;
            break;
        }
        const auto number = parseJsonNumber(text, i);
        if (!number || count >= 16) {
            return std::nullopt;
        }
        values[count++] = static_cast<float>(*number);
        skipWs(text, i);
        if (i < text.size() && text[i] == ',') {
            ++i;
        }
    }
    if (count != 16) {
        return std::nullopt;
    }
    return values;
}

inline std::optional<CameraConfigEntry> parseCameraObject(const std::string& text, size_t& i) {
    if (!matchLiteral(text, i, '{')) {
        return std::nullopt;
    }
    CameraConfigEntry entry;
    while (i < text.size()) {
        skipWs(text, i);
        if (i < text.size() && text[i] == '}') {
            ++i;
            break;
        }
        const auto key = parseJsonString(text, i);
        if (!key || !matchLiteral(text, i, ':')) {
            return std::nullopt;
        }
        if (*key == "serial") {
            const auto serial = parseJsonString(text, i);
            if (!serial) {
                return std::nullopt;
            }
            entry.serial = *serial;
        } else if (*key == "trafo") {
            const auto trafo = parseTrafoArray(text, i);
            if (!trafo) {
                return std::nullopt;
            }
            entry.trafo = *trafo;
            entry.hasTrafo = true;
        } else if (*key == "ox") {
            if (const auto v = parseJsonNumber(text, i)) {
                entry.oxMm = static_cast<float>(*v);
            }
        } else if (*key == "oy") {
            if (const auto v = parseJsonNumber(text, i)) {
                entry.oyMm = static_cast<float>(*v);
            }
        } else if (*key == "oz") {
            if (const auto v = parseJsonNumber(text, i)) {
                entry.ozMm = static_cast<float>(*v);
            }
        } else {
            skipValue(text, i);
        }
        skipWs(text, i);
        if (i < text.size() && text[i] == ',') {
            ++i;
        }
    }
    if (entry.serial.empty()) {
        return std::nullopt;
    }
    return entry;
}

inline size_t findCamerasArray(const std::string& text) {
    const std::string needle = "\"cameras\"";
    const size_t pos = text.find(needle);
    if (pos == std::string::npos) {
        return std::string::npos;
    }
    size_t i = pos + needle.size();
    skipWs(text, i);
    if (!matchLiteral(text, i, ':')) {
        return std::string::npos;
    }
    skipWs(text, i);
    if (i >= text.size() || text[i] != '[') {
        return std::string::npos;
    }
    return i;
}

}  // namespace detail

inline std::vector<CameraConfigEntry> loadCameraConfigFile(const std::string& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input.is_open()) {
        throw std::runtime_error("Failed to open camera config: " + path);
    }
    std::ostringstream buffer;
    buffer << input.rdbuf();
    const std::string text = buffer.str();

    const size_t arrayStart = detail::findCamerasArray(text);
    if (arrayStart == std::string::npos) {
        throw std::runtime_error("Camera config missing \"cameras\" array: " + path);
    }

    size_t i = arrayStart + 1;
    std::vector<CameraConfigEntry> cameras;
    while (i < text.size()) {
        detail::skipWs(text, i);
        if (i < text.size() && text[i] == ']') {
            break;
        }
        if (const auto entry = detail::parseCameraObject(text, i)) {
            cameras.push_back(*entry);
        }
        detail::skipWs(text, i);
        if (i < text.size() && text[i] == ',') {
            ++i;
        }
    }

    if (cameras.empty()) {
        throw std::runtime_error("Camera config has no valid camera entries: " + path);
    }
    return cameras;
}
