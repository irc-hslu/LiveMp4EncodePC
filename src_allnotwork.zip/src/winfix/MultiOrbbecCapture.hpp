#pragma once

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <deque>
#include <future>
#include <iostream>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "CameraConfig.hpp"
#include "OrbbecCapture.hpp"
#include "PointCloudMerge.hpp"
#include "multi_orbbec_debug.hpp"
#include "orbbec_safe.hpp"

struct MultiOrbbecCaptureConfig {
    OrbbecCaptureConfig baseCapture;
    std::vector<CameraConfigEntry> cameras;
};

/// Captures from multiple Orbbec devices, applies cameraconfig trafo, merges into one PointCloudFrame.
class MultiOrbbecCapture {
public:
    explicit MultiOrbbecCapture(MultiOrbbecCaptureConfig config) : config_(std::move(config)) {}

    ~MultiOrbbecCapture() { stop(); }

    MultiOrbbecCapture(const MultiOrbbecCapture&) = delete;
    MultiOrbbecCapture& operator=(const MultiOrbbecCapture&) = delete;

#if defined(ORBBEC_SDK_FOUND)
    void prepareDevice() {
        const uint32_t deviceCount = orbbecSafeGetDeviceCount();
        if (deviceCount == 0) {
            throw std::runtime_error(
                "No Orbbec camera found. Check USB, drivers, and close Orbbec Viewer if it is using the device.");
        }

        std::cerr << "[orbbec] Found " << deviceCount << " device(s), config lists "
                  << config_.cameras.size() << " camera(s)\n"
                  << std::flush;

        for (const auto& camera : config_.cameras) {
            if (!orbbecSafeIsSerialConnected(camera.serial)) {
                throw std::runtime_error("Configured camera not connected: " + camera.serial);
            }
            std::cerr << "[orbbec] Config camera present: " << camera.serial << "\n" << std::flush;
        }
    }
#endif

    void start(bool forceSynthetic = false) {
        if (running_.exchange(true)) {
            return;
        }
        pipelinesReady_ = false;
        MULTI_DEBUG_MAIN("MultiOrbbecCapture::start:enter");

        if (forceSynthetic || config_.cameras.empty()) {
            MULTI_DEBUG_MAIN("MultiOrbbecCapture::start:synthetic");
            startSynthetic();
            return;
        }

#if defined(ORBBEC_SDK_FOUND)
        const size_t cameraCount = config_.cameras.size();
        MULTI_DEBUG_MAIN("MultiOrbbecCapture::start:real-cameras");
        cameraSlots_.clear();
        cameraSlots_.reserve(cameraCount);
        deviceSessions_.clear();
        deviceSessions_.reserve(cameraCount);

        MULTI_DEBUG_MULTI("orbbecSafeQueryDevices:before");
        deviceSessionQuery_ = orbbecSafeQueryDevices();
        MULTI_DEBUG_MULTI("orbbecSafeQueryDevices:after");
        const uint32_t connectedDevices =
            deviceSessionQuery_.deviceList ? deviceSessionQuery_.deviceList->getCount() : 0U;
        std::cerr << "[multi-orbbec] Orbbec devices visible: " << connectedDevices << "\n" << std::flush;
        if (!deviceSessionQuery_.deviceList || connectedDevices < cameraCount) {
            reportCaptureError("Not enough Orbbec devices connected for multi-camera config");
            return;
        }

        const size_t perCameraPointBudget =
            config_.baseCapture.maxPointsPerFrame > 0
                ? (std::max)(size_t{1024}, config_.baseCapture.maxPointsPerFrame / cameraCount)
                : config_.baseCapture.maxPointsPerFrame;

        std::cerr << "[multi-orbbec] Starting " << cameraCount
                  << " camera(s) sequentially (one OrbbecCapture per camera)\n"
                  << std::flush;

        for (size_t cameraIndex = 0; cameraIndex < cameraCount; ++cameraIndex) {
            MULTI_DEBUG_MULTI_STR("camera loop index=" + std::to_string(cameraIndex));
            cameraSlots_.push_back(std::make_unique<CameraSlot>());

            const auto& calibration = config_.cameras[cameraIndex];
            DeviceSession session;

            MULTI_DEBUG_MULTI_STR("bind device serial=" + calibration.serial);
            session.device =
                orbbecSafeBindDeviceBySerial(*deviceSessionQuery_.deviceList, calibration.serial);
            if (!session.device) {
                reportCaptureError("Orbbec device not found for serial: " + calibration.serial);
                stop();
                return;
            }
            orbbecSafeLogDeviceLabel(session.device, calibration.serial);

            OrbbecCaptureConfig cameraConfig = config_.baseCapture;
            cameraConfig.multiCameraSession = true;
            cameraConfig.deviceSerial = calibration.serial;
            cameraConfig.hasWorldTransform = calibration.hasTrafo;
            cameraConfig.worldTransform = calibration.trafo;
            cameraConfig.layoutOffsetMm[0] = calibration.oxMm;
            cameraConfig.layoutOffsetMm[1] = calibration.oyMm;
            cameraConfig.layoutOffsetMm[2] = calibration.ozMm;
            cameraConfig.maxPointsPerFrame = perCameraPointBudget;
            cameraConfig.onFrameCaptured = {};
            cameraConfig.onWorldSliceCaptured = [this, cameraIndex](WorldPointCloudSlice slice) {
                onCameraWorldSlice(cameraIndex, std::move(slice));
            };

            auto readyPromise = std::make_shared<std::promise<void>>();
            std::future<void> readyFuture = readyPromise->get_future();
            cameraConfig.onPipelineReady = [readyPromise]() {
                try {
                    readyPromise->set_value();
                } catch (...) {
                }
            };

            session.capture = std::make_unique<OrbbecCapture>(cameraConfig);
            session.capture->setBoundDevice(session.device);
            session.capture->setSdkContext(deviceSessionQuery_.context);
            MULTI_DEBUG_MULTI_STR("OrbbecCapture constructed serial=" + calibration.serial);

            std::cerr << "[multi-orbbec] Starting capture " << (cameraIndex + 1) << "/" << cameraCount << " ("
                      << calibration.serial << ")\n"
                      << std::flush;
            MULTI_DEBUG_MULTI("OrbbecCapture::start:before");
            session.capture->start(false);
            MULTI_DEBUG_MULTI("OrbbecCapture::start:after");
            deviceSessions_.push_back(std::move(session));

            MULTI_DEBUG_MULTI("wait pipeline ready:before");
            const auto waitStatus = readyFuture.wait_for(std::chrono::seconds(90));
            MULTI_DEBUG_MULTI("wait pipeline ready:after");
            if (waitStatus != std::future_status::ready) {
                reportCaptureError("Orbbec pipeline ready timeout for serial: " + calibration.serial);
                stop();
                return;
            }
            if (deviceSessions_.back().capture->captureFailed()) {
                const auto error = deviceSessions_.back().capture->captureError();
                reportCaptureError(error ? *error : "Orbbec capture failed for serial: " + calibration.serial);
                stop();
                return;
            }

            std::cerr << "[multi-orbbec] Camera " << (cameraIndex + 1) << "/" << cameraCount << " pipeline ready ("
                      << calibration.serial << ")\n"
                      << std::flush;

            if (cameraIndex + 1 < cameraCount) {
                std::this_thread::sleep_for(std::chrono::milliseconds(2000));
            }
        }

        pipelinesReady_ = true;
        MULTI_DEBUG_MAIN("MultiOrbbecCapture::start:all-pipelines-ready");
#else
        startSynthetic();
#endif
    }

    void stop() {
        MULTI_DEBUG_MAIN("MultiOrbbecCapture::stop:enter");
        if (!running_.exchange(false)) {
            return;
        }

        for (auto& session : deviceSessions_) {
            if (session.capture) {
                session.capture->stop();
            }
        }
        deviceSessions_.clear();
        deviceSessionQuery_ = {};
        cameraSlots_.clear();

        if (syntheticThread_.joinable()) {
            syntheticThread_.request_stop();
            syntheticThread_.join();
        }
        {
            std::lock_guard lock(queueMutex_);
            queue_.clear();
        }
    }

    std::optional<PointCloudFrame> tryPopFrame() {
        std::lock_guard lock(queueMutex_);
        if (queue_.empty()) {
            return std::nullopt;
        }
        PointCloudFrame frame = std::move(queue_.front());
        queue_.pop_front();
        return frame;
    }

    std::optional<PointCloudFrame> waitPopFrame(std::chrono::milliseconds timeout) {
        const auto deadline = std::chrono::steady_clock::now() + timeout;
        while (running_.load()) {
            if (auto frame = tryPopFrame()) {
                return frame;
            }
            if (std::chrono::steady_clock::now() >= deadline) {
                return std::nullopt;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        return std::nullopt;
    }

    bool isRunning() const {
        if (!running_.load()) {
            return false;
        }
#if defined(ORBBEC_SDK_FOUND)
        for (const auto& session : deviceSessions_) {
            if (session.capture && !session.capture->isRunning()) {
                return false;
            }
        }
#endif
        return true;
    }

    bool captureFailed() const {
        if (captureFailed_.load()) {
            return true;
        }
#if defined(ORBBEC_SDK_FOUND)
        for (const auto& session : deviceSessions_) {
            if (session.capture && session.capture->captureFailed()) {
                return true;
            }
        }
#endif
        return false;
    }

    bool pipelinesReady() const { return pipelinesReady_.load(); }

    std::optional<std::string> captureError() const {
        std::lock_guard lock(captureErrorMutex_);
        if (!captureError_.empty()) {
            return captureError_;
        }
#if defined(ORBBEC_SDK_FOUND)
        for (const auto& session : deviceSessions_) {
            if (session.capture) {
                if (const auto error = session.capture->captureError()) {
                    return error;
                }
            }
        }
#endif
        return std::nullopt;
    }

    void setOnFrameCaptured(std::function<void(const PointCloudFrame&)> callback) {
        onFrameCaptured_ = std::move(callback);
    }

private:
    struct CameraSlot {
        std::mutex mutex;
        WorldPointCloudSlice latest;
        bool hasFrame = false;
    };

#if defined(ORBBEC_SDK_FOUND)
    struct DeviceSession {
        std::shared_ptr<ob::Device> device;
        std::unique_ptr<OrbbecCapture> capture;
    };
    OrbbecDeviceQuery deviceSessionQuery_;
#endif

    void reportCaptureError(std::string message) {
        MULTI_DEBUG_MULTI("reportCaptureError");
        multiOrbbecDebug::logLastStepOnError("multi");
        {
            std::lock_guard lock(captureErrorMutex_);
            captureError_ = std::move(message);
        }
        captureFailed_ = true;
        running_ = false;
        std::cerr << "[multi-orbbec] ERROR: " << captureError_ << "\n" << std::flush;
    }

    void pushFrame(PointCloudFrame frame) {
        if (frame.geometry.empty() || frame.geometry.size() != frame.attributes.size()) {
            return;
        }
        if (onFrameCaptured_) {
            onFrameCaptured_(frame);
        }
        {
            std::lock_guard lock(queueMutex_);
            while (queue_.size() >= config_.baseCapture.maxQueueDepth) {
                queue_.pop_front();
            }
            queue_.push_back(std::move(frame));
        }
    }

    void onCameraWorldSlice(size_t cameraIndex, WorldPointCloudSlice slice) {
        if (!running_.load()) {
            return;
        }
        if (cameraIndex >= cameraSlots_.size()) {
            return;
        }

        if (slice.frameNumber < 3U || slice.frameNumber % 50U == 0U) {
            MULTI_DEBUG_MULTI_STR(
                "onCameraWorldSlice cam=" + std::to_string(cameraIndex) + " frame=" +
                std::to_string(slice.frameNumber) + " pts=" + std::to_string(slice.positionsMeters.size()));
        }

        {
            std::lock_guard lock(cameraSlots_[cameraIndex]->mutex);
            cameraSlots_[cameraIndex]->latest = std::move(slice);
            cameraSlots_[cameraIndex]->hasFrame = true;
        }

        publishMergedFrame();
    }

    void publishMergedFrame() {
        MULTI_DEBUG_MULTI("publishMergedFrame:enter");
        std::vector<WorldPointCloudSlice> slices;
        slices.reserve(cameraSlots_.size());

        for (const auto& slot : cameraSlots_) {
            std::lock_guard lock(slot->mutex);
            if (!slot->hasFrame) {
                MULTI_DEBUG_MULTI("publishMergedFrame:waiting-for-all-slots");
                return;
            }
            slices.push_back(slot->latest);
        }

        MULTI_DEBUG_MULTI("publishMergedFrame:mergeWorldSlicesToFrame:before");
        PointCloudFrame merged = mergeWorldSlicesToFrame(
            slices,
            mergedFrameNumber_++,
            config_.baseCapture.geoBitDepthInput,
            config_.baseCapture.maxPointsPerFrame);

        MULTI_DEBUG_MULTI("publishMergedFrame:mergeWorldSlicesToFrame:after");
        if (merged.geometry.empty()) {
            MULTI_DEBUG_MULTI("publishMergedFrame:empty-merged");
            return;
        }

        if (merged.frameNumber == 0) {
            std::cerr << "[multi-orbbec] First merged cloud: " << merged.geometry.size() << " points from "
                      << slices.size() << " cameras\n"
                      << std::flush;
        }

        pushFrame(std::move(merged));
        MULTI_DEBUG_MULTI("publishMergedFrame:pushFrame:done");
    }

    void startSynthetic() {
        const int captureFps = config_.baseCapture.colorFps;
        const size_t cameraCount = config_.cameras.size();
        const size_t maxPointsPerFrame = config_.baseCapture.maxPointsPerFrame;
        const size_t geoBitDepthInput = config_.baseCapture.geoBitDepthInput;
        std::vector<CameraConfigEntry> cameras = config_.cameras;

        syntheticThread_ = std::jthread([this,
                                         captureFps,
                                         cameraCount,
                                         maxPointsPerFrame,
                                         geoBitDepthInput,
                                         cameras = std::move(cameras)](std::stop_token stopToken) mutable {
            captureLoopSyntheticMulti(
                stopToken, captureFps, cameraCount, maxPointsPerFrame, geoBitDepthInput, cameras);
        });
        pipelinesReady_ = true;
    }

    void captureLoopSyntheticMulti(
        std::stop_token stopToken,
        int captureFps,
        size_t cameraCount,
        size_t maxPointsPerFrame,
        size_t geoBitDepthInput,
        const std::vector<CameraConfigEntry>& cameras) {
        uint64_t frameNumber = 0;
        const size_t activeCameras = (std::max)(size_t{1}, cameraCount);

        while (!stopToken.stop_requested() && running_.load()) {
            std::vector<WorldPointCloudSlice> slices;
            slices.reserve(activeCameras);

            for (size_t cameraIndex = 0; cameraIndex < activeCameras; ++cameraIndex) {
                WorldPointCloudSlice slice;
                slice.frameNumber = frameNumber;
                slice.positionsMeters.reserve(1024);
                slice.attributes.reserve(1024);

                const float layoutX =
                    cameraIndex < cameras.size() ? cameras[cameraIndex].oxMm / kMmPerMeter : 0.F;
                const float layoutY =
                    cameraIndex < cameras.size() ? cameras[cameraIndex].oyMm / kMmPerMeter : 0.F;
                const float layoutZ =
                    cameraIndex < cameras.size() ? cameras[cameraIndex].ozMm / kMmPerMeter : 0.F;
                const float centerX = static_cast<float>(cameraIndex) * 0.35F + layoutX;
                const float centerY = layoutY;
                const float centerZ = layoutZ;

                for (int y = 0; y < 8; ++y) {
                    for (int x = 0; x < 8; ++x) {
                        const float xf = static_cast<float>(x) / 8.F;
                        const float yf = static_cast<float>(y) / 8.F;
                        const float zf = 0.2F + 0.05F * std::sin((xf + yf + frameNumber * 0.05F) * 6.2831853F);
                        slice.positionsMeters.push_back({centerX + xf * 0.15F, centerY + yf * 0.15F, centerZ + zf});
                        slice.attributes.push_back(AttributePoint{
                            static_cast<uint8_t>((cameraIndex * 60 + xf * 180.F)),
                            static_cast<uint8_t>(yf * 255.F),
                            static_cast<uint8_t>(128 + 127 * std::sin(xf * 6.2831853F)),
                        });
                    }
                }
                slices.push_back(std::move(slice));
            }

            PointCloudFrame merged =
                mergeWorldSlicesToFrame(slices, frameNumber, geoBitDepthInput, maxPointsPerFrame);
            if (!merged.geometry.empty()) {
                pushFrame(std::move(merged));
            }

            ++frameNumber;
            std::this_thread::sleep_for(std::chrono::milliseconds(1000 / (std::max)(1, captureFps)));
        }
    }

    MultiOrbbecCaptureConfig config_;
    std::function<void(const PointCloudFrame&)> onFrameCaptured_;
    std::vector<std::unique_ptr<CameraSlot>> cameraSlots_;
#if defined(ORBBEC_SDK_FOUND)
    std::vector<DeviceSession> deviceSessions_;
#endif
    std::jthread syntheticThread_;
    std::atomic<bool> running_{false};
    std::atomic<bool> captureFailed_{false};
    std::atomic<bool> pipelinesReady_{false};
    mutable std::mutex captureErrorMutex_;
    std::string captureError_;
    std::mutex queueMutex_;
    std::deque<PointCloudFrame> queue_;
    uint64_t mergedFrameNumber_ = 0;
};
