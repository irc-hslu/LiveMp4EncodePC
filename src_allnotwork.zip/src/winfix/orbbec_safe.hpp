#pragma once

#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <libobsensor/ObSensor.hpp>

/// Serializes Orbbec SDK calls — required for multi-camera on Windows (recursive: stop may run under start).
std::recursive_mutex& orbbecSdkMutex();

struct OrbbecRgbdPipelineHandles {
    std::shared_ptr<ob::Pipeline> pipeline;
    std::shared_ptr<ob::Align> alignFilter;
    std::shared_ptr<ob::PointCloudFilter> pointCloudFilter;
};

/// Returns connected device count (0 on failure).
uint32_t orbbecSafeGetDeviceCount();

struct OrbbecDeviceQuery {
    std::shared_ptr<ob::Context> context;
    std::shared_ptr<ob::DeviceList> deviceList;
};

/// Query devices once; empty deviceList on failure.
OrbbecDeviceQuery orbbecSafeQueryDevices();

/// True if serial is connected (empty serial = at least one device).
bool orbbecSafeIsSerialConnected(const std::string& serial);

/// Find device by serial via index walk (safer than getDeviceBySN on some Windows multi-USB setups).
std::shared_ptr<ob::Device> orbbecSafeFindDeviceBySerial(ob::DeviceList& deviceList, const std::string& serial);

/// First connected device, or nullptr.
std::shared_ptr<ob::Device> orbbecSafeGetDefaultDevice();

/// Starts Orbbec pipeline; catches SDK access violations (MSVC /EHa or SEH wrapper).
bool orbbecSafePipelineStart(
    ob::Pipeline& pipeline,
    const std::shared_ptr<ob::Config>& config,
    bool enableFrameSync = false);

bool orbbecSafeTryStartRgbdPipeline(
    const std::shared_ptr<ob::Device>& device,
    OBFormat colorFormat,
    OrbbecRgbdPipelineHandles& out,
    bool multiCameraReducedResolution = false);

bool orbbecSafeTryStartDepthOnlyPipeline(
    const std::shared_ptr<ob::Device>& device,
    std::shared_ptr<ob::Pipeline>& pipeline,
    std::shared_ptr<ob::PointCloudFilter>& pointCloudFilter);

std::shared_ptr<ob::FrameSet> orbbecSafeWaitForFrameset(ob::Pipeline& pipeline, uint32_t timeoutMs);

std::shared_ptr<ob::Frame> orbbecSafeProcessRgbdPointCloud(
    ob::Align& alignFilter,
    ob::PointCloudFilter& pointCloudFilter,
    const std::shared_ptr<ob::FrameSet>& frameSet);

/// Point cloud from a D2C-aligned FrameSet (pipeline setAlignMode, no Align filter).
std::shared_ptr<ob::Frame> orbbecSafeProcessFrameSetPointCloud(
    ob::PointCloudFilter& pointCloudFilter,
    const std::shared_ptr<ob::FrameSet>& frameSet);

std::shared_ptr<ob::Frame> orbbecSafeProcessDepthPointCloud(
    ob::PointCloudFilter& pointCloudFilter,
    const std::shared_ptr<ob::DepthFrame>& depthFrame);

void orbbecSafePipelineStop(ob::Pipeline& pipeline);

/// Cooldown after a failed pipeline (Windows MFT decoder release).
void orbbecPipelineReleaseCooldown();

void orbbecSafeLogDeviceLabel(const std::shared_ptr<ob::Device>& device, const std::string& serial);

/// Build serial -> device map from one device list walk (multi-camera).
std::vector<std::shared_ptr<ob::Device>> orbbecSafeBindDevicesBySerial(
    ob::DeviceList& deviceList,
    const std::vector<std::string>& serialsInOrder);

std::shared_ptr<ob::Pipeline> orbbecSafeCreatePipeline(const std::shared_ptr<ob::Device>& device);

bool orbbecSafeStartRgbdOnPipeline(ob::Pipeline& pipeline, OrbbecRgbdPipelineHandles& out);

/// Bind device from an existing device list (shared Context). Prefer getDeviceBySN.
std::shared_ptr<ob::Device> orbbecSafeBindDeviceBySerial(ob::DeviceList& deviceList, const std::string& serial);

/// Open device on an isolated Context (plylivestream pattern). Keeps context alive via outContext.
bool orbbecSafeOpenDeviceBySerial(
    const std::string& serial,
    std::shared_ptr<ob::Context>& outContext,
    std::shared_ptr<ob::Device>& outDevice);
