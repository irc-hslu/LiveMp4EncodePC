#pragma once

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <deque>
#include <iostream>
#include <mutex>
#include <functional>
#include <optional>
#include <sstream>

#include "uvgutils/sync.hpp"
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#include <eh.h>
#endif

#include "uvgutils/utils.hpp"
#include "uvgvpcc/uvgvpcc.hpp"

#include "CameraConfig.hpp"

using GeometryPoint = uvgutils::VectorN<uvgvpcc_enc::typeGeometryInput, 3>;
using AttributePoint = uvgutils::VectorN<uint8_t, 3>;

#if defined(ORBBEC_SDK_FOUND)
#include <algorithm>
#include <libobsensor/ObSensor.hpp>
#include "orbbec_safe.hpp"
#include "multi_orbbec_debug.hpp"
#ifdef ERROR
#undef ERROR
#endif
#endif

/// Orbbec D2C-aligned RGB point cloud (Align + PointCloudFilter) for uvgVPCCenc.
struct PointCloudFrame {
    uint64_t frameNumber = 0;
    float origin[3]{0.F, 0.F, 0.F};
    float quantScale = 1.F;
    std::vector<GeometryPoint> geometry;
    std::vector<AttributePoint> attributes;
};

/// World-space meter samples from one camera (before multi-camera merge / voxel quantization).
struct WorldPointCloudSlice {
    uint64_t frameNumber = 0;
    std::vector<std::array<float, 3>> positionsMeters;
    std::vector<AttributePoint> attributes;
};

struct OrbbecCaptureConfig {
    // 640x480 keeps point counts manageable for live V-PCC on Windows.
    int colorWidth = 1920;
    int colorHeight = 1080;
    int colorFps = 30;
    int depthWidth = 640;
    int depthHeight = 480;
    int depthFps = 30;
    size_t geoBitDepthInput = 9;
    size_t maxQueueDepth = 1;
    size_t maxPointsPerFrame = 500000;
    bool enableSyntheticFallback = true;
    /// When non-empty, bind capture to this device serial (required for multi-camera).
    std::string deviceSerial;
    /// cameraconfig.json column-major trafo (camera frame meters → world meters).
    std::array<float, 16> worldTransform{};
    bool hasWorldTransform = false;
    float layoutOffsetMm[3]{0.F, 0.F, 0.F};
    /// When set, emit world-space slices for multi-camera merge instead of quantized PointCloudFrame.
    std::function<void(WorldPointCloudSlice)> onWorldSliceCaptured;
    /// Called on the capture thread when a new point cloud frame is ready (for live preview).
    std::function<void(const PointCloudFrame&)> onFrameCaptured;
    /// Member of a multi-camera session: 720p streams + serialized SDK access.
    bool multiCameraSession = false;
    /// Fired on the capture thread after pipeline start and warmup frames.
    std::function<void()> onPipelineReady;
};

class OrbbecCapture {
public:
    explicit OrbbecCapture(OrbbecCaptureConfig config = {})
        : config_(std::move(config)) {}

    ~OrbbecCapture() { stop(); }

    OrbbecCapture(const OrbbecCapture&) = delete;
    OrbbecCapture& operator=(const OrbbecCapture&) = delete;

#if defined(ORBBEC_SDK_FOUND)
    /// Pre-bound device from multi-camera coordinator (avoids concurrent queryDeviceList on capture threads).
    void setBoundDevice(std::shared_ptr<ob::Device> device) { boundDevice_ = std::move(device); }

    /// Keep shared SDK Context alive when device comes from multi-camera coordinator.
    void setSdkContext(std::shared_ptr<ob::Context> context) { sdkContext_ = std::move(context); }

    /// Probe for a camera on the main thread. Does not keep the device open (capture thread owns the pipeline).
    void prepareDevice() {
        std::cerr << "[orbbec] Querying devices...\n" << std::flush;
        const uint32_t deviceCount = orbbecSafeGetDeviceCount();
        if (deviceCount == 0) {
            throw std::runtime_error(
                "No Orbbec camera found. Check USB, drivers, and close Orbbec Viewer if it is using the device.");
        }

        std::cerr << "[orbbec] Found " << deviceCount << " device(s)\n" << std::flush;
        // Keep Context alive while reading device info.
        const auto query = orbbecSafeQueryDevices();
        if (query.deviceList && query.deviceList->getCount() > 0) {
            if (auto device = query.deviceList->getDevice(0)) {
                if (auto info = device->getDeviceInfo()) {
                    std::cerr << "[orbbec] Using device: " << info->name() << "\n" << std::flush;
                }
            }
        }
    }
#endif

    void start(bool forceSynthetic = false) {
        if (running_.exchange(true)) {
            return;
        }

#if defined(ORBBEC_SDK_FOUND)
        if (forceSynthetic) {
            captureThread_ = std::jthread([this](std::stop_token stopToken) { captureLoopSynthetic(stopToken); });
        } else {
            captureThread_ = std::jthread([this](std::stop_token stopToken) { captureLoopOrbbec(stopToken); });
        }
#else
        if (!config_.enableSyntheticFallback) {
            running_ = false;
            throw std::runtime_error(
                "Orbbec SDK not found at configure time. Set ORBBEC_SDK_DIR or enable synthetic fallback.");
        }
        captureThread_ = std::jthread([this](std::stop_token stopToken) { captureLoopSynthetic(stopToken); });
#endif
    }

    void stop() {
        if (!running_.exchange(false)) {
            return;
        }
        if (captureThread_.joinable()) {
            captureThread_.request_stop();
            captureThread_.join();
        }
        {
            std::lock_guard lock(queueMutex_);
            queue_.clear();
        }
    }

    std::optional<PointCloudFrame> tryPopFrame() {
        std::lock_guard lock(queueMutex_);
        if (queue_.empty()) {
            return std::nullopt;
        }
        PointCloudFrame frame = std::move(queue_.front());
        queue_.pop_front();
        return frame;
    }

    std::optional<PointCloudFrame> waitPopFrame(std::chrono::milliseconds timeout) {
        const auto deadline = std::chrono::steady_clock::now() + timeout;
        while (running_.load()) {
            if (auto frame = tryPopFrame()) {
                return frame;
            }
            if (std::chrono::steady_clock::now() >= deadline) {
                return std::nullopt;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        return std::nullopt;
    }

    bool isRunning() const { return running_.load(); }

    bool isPipelineReady() const { return pipelineReady_.load(); }

    bool captureFailed() const { return captureFailed_.load(); }

    std::optional<std::string> captureError() const {
        std::lock_guard lock(captureErrorMutex_);
        if (captureError_.empty()) {
            return std::nullopt;
        }
        return captureError_;
    }

private:
    void reportCaptureError(std::string message) {
        if (config_.multiCameraSession) {
            multiOrbbecDebug::logLastStepOnError("orbbec");
        }
        {
            std::lock_guard lock(captureErrorMutex_);
            captureError_ = std::move(message);
        }
        captureFailed_ = true;
        running_ = false;
        std::cerr << "[orbbec] ERROR: " << captureError_ << "\n" << std::flush;
    }
    static uvgvpcc_enc::typeGeometryInput quantizeCoord(float meters, float origin, float scale, size_t geoBitDepthInput) {
        const float qf = (meters - origin) * scale;
        const float maxValue = static_cast<float>((static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
        if (qf < 0.F || qf > maxValue) {
            return static_cast<uvgvpcc_enc::typeGeometryInput>(maxValue + 1U);
        }
        return static_cast<uvgvpcc_enc::typeGeometryInput>(qf);
    }

    static bool coordinateFitsVoxelGrid(const GeometryPoint& point, size_t geoBitDepthInput) {
        const auto maxValue = static_cast<uvgvpcc_enc::typeGeometryInput>(
            (static_cast<uint32_t>(1) << geoBitDepthInput) - 1U);
        return point[0] <= maxValue && point[1] <= maxValue && point[2] <= maxValue;
    }

    static uint8_t colorChannelToByte(float channel) {
        const float clamped = (std::max)(0.F, (std::min)(channel, 255.F));
        return static_cast<uint8_t>(clamped);
    }

    void pushFrame(PointCloudFrame frame) {
        if (config_.onFrameCaptured) {
            config_.onFrameCaptured(frame);
        }
        {
            std::lock_guard lock(queueMutex_);
            while (queue_.size() >= config_.maxQueueDepth) {
                queue_.pop_front();
            }
            queue_.push_back(std::move(frame));
        }
    }

#if defined(ORBBEC_SDK_FOUND)
    enum class OrbbecCaptureMode { RgbdD2c, DepthOnly };

    static const char* colorFormatName(OBFormat format) {
        switch (format) {
        case OB_FORMAT_RGB:
            return "RGB";
        case OB_FORMAT_MJPG:
            return "MJPG";
        default:
            return "unknown";
        }
    }

    void captureLoopOrbbec(std::stop_token stopToken) {
#ifdef _WIN32
        // Convert Windows SEH faults (e.g. 0xc0000005) into C++ exceptions we can log.
        _set_se_translator([](unsigned int code, _EXCEPTION_POINTERS*) {
            std::ostringstream message;
            message << "Windows SEH exception: 0x" << std::hex << code;
            throw std::runtime_error(message.str());
        });
#endif
        try {
            captureLoopOrbbecImpl(stopToken);
        } catch (const ob::Error& error) {
            reportCaptureError(std::string("Orbbec SDK error: ") + error.getMessage());
        } catch (const std::exception& error) {
            reportCaptureError(error.what());
        } catch (...) {
            reportCaptureError("Unknown Orbbec capture failure");
        }
    }

    bool tryStartRgbdPipeline(
        const std::shared_ptr<ob::Device>& device,
        std::shared_ptr<ob::Pipeline>& pipeline,
        OBFormat colorFormat,
        std::shared_ptr<ob::Align>& alignFilter,
        std::shared_ptr<ob::PointCloudFilter>& pointCloudFilter) {
        OrbbecRgbdPipelineHandles handles;
        if (!orbbecSafeTryStartRgbdPipeline(device, colorFormat, handles, config_.multiCameraSession)) {
            return false;
        }
        pipeline = std::move(handles.pipeline);
        alignFilter = std::move(handles.alignFilter);
        pointCloudFilter = std::move(handles.pointCloudFilter);
        return true;
    }

    bool tryStartDepthOnlyPipeline(
        const std::shared_ptr<ob::Device>& device,
        std::shared_ptr<ob::Pipeline>& pipeline,
        std::shared_ptr<ob::PointCloudFilter>& pointCloudFilter) {
        return orbbecSafeTryStartDepthOnlyPipeline(device, pipeline, pointCloudFilter);
    }

    void logOrbbecDevice(const std::shared_ptr<ob::Pipeline>& pipeline) {
        if (const auto device = pipeline->getDevice()) {
            if (const auto info = device->getDeviceInfo()) {
                std::cerr << "[orbbec] Device: " << info->name() << "\n" << std::flush;
            }
        }
    }

    void emitWorldSliceFromRgbPoints(
        uint64_t frameNumber,
        const OBColorPoint* points,
        uint32_t pointCount,
        uint32_t stride) const {
        WorldPointCloudSlice slice;
        slice.frameNumber = frameNumber;
        const uint32_t reserveCount =
            (std::min)(pointCount / stride, static_cast<uint32_t>(config_.maxPointsPerFrame));
        slice.positionsMeters.reserve(reserveCount);
        slice.attributes.reserve(reserveCount);

        for (uint32_t i = 0; i < pointCount; i += stride) {
            if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                continue;
            }

            float xWorld = 0.F;
            float yWorld = 0.F;
            float zWorld = 0.F;
            if (config_.hasWorldTransform) {
                transformOrbbecPointToWorld(
                    points[i].x,
                    points[i].y,
                    points[i].z,
                    config_.worldTransform,
                    config_.layoutOffsetMm[0],
                    config_.layoutOffsetMm[1],
                    config_.layoutOffsetMm[2],
                    xWorld,
                    yWorld,
                    zWorld);
            } else {
                xWorld = points[i].x / kMmPerMeter;
                yWorld = points[i].y / kMmPerMeter;
                zWorld = points[i].z / kMmPerMeter;
            }

            slice.positionsMeters.push_back({xWorld, yWorld, zWorld});
            slice.attributes.push_back(AttributePoint{
                colorChannelToByte(points[i].r),
                colorChannelToByte(points[i].g),
                colorChannelToByte(points[i].b)});
        }

        if (!slice.positionsMeters.empty() && config_.onWorldSliceCaptured) {
            config_.onWorldSliceCaptured(std::move(slice));
        }
    }

    void emitWorldSliceFromDepthPoints(
        uint64_t frameNumber,
        const OBPoint* points,
        uint32_t pointCount,
        uint32_t stride) const {
        WorldPointCloudSlice slice;
        slice.frameNumber = frameNumber;
        const uint32_t reserveCount =
            (std::min)(pointCount / stride, static_cast<uint32_t>(config_.maxPointsPerFrame));
        slice.positionsMeters.reserve(reserveCount);
        slice.attributes.reserve(reserveCount);

        for (uint32_t i = 0; i < pointCount; i += stride) {
            if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                continue;
            }

            float xWorld = 0.F;
            float yWorld = 0.F;
            float zWorld = 0.F;
            if (config_.hasWorldTransform) {
                transformOrbbecPointToWorld(
                    points[i].x,
                    points[i].y,
                    points[i].z,
                    config_.worldTransform,
                    config_.layoutOffsetMm[0],
                    config_.layoutOffsetMm[1],
                    config_.layoutOffsetMm[2],
                    xWorld,
                    yWorld,
                    zWorld);
            } else {
                xWorld = points[i].x / kMmPerMeter;
                yWorld = points[i].y / kMmPerMeter;
                zWorld = points[i].z / kMmPerMeter;
            }

            const uint8_t gray = static_cast<uint8_t>((std::max)(
                0.F,
                (std::min)(255.F, (points[i].z - kMinDepthMm) / (kMaxDepthMm - kMinDepthMm) * 255.F)));
            slice.positionsMeters.push_back({xWorld, yWorld, zWorld});
            slice.attributes.push_back(AttributePoint{gray, gray, gray});
        }

        if (!slice.positionsMeters.empty() && config_.onWorldSliceCaptured) {
            config_.onWorldSliceCaptured(std::move(slice));
        }
    }

    static constexpr float kMinDepthMm = 20.F;
    static constexpr float kMaxDepthMm = 3000.F;

    void captureLoopOrbbecImpl(std::stop_token stopToken) {
        struct MultiDebugScope {
            explicit MultiDebugScope(const OrbbecCaptureConfig& config) {
                if (config.multiCameraSession) {
                    multiOrbbecDebug::setCameraContext(config.deviceSerial.c_str());
                }
            }
            ~MultiDebugScope() { multiOrbbecDebug::clearCameraContext(); }
        } debugScope(config_);
        MULTI_DEBUG_ORBBEC("captureLoopOrbbecImpl:enter");

        if (!config_.multiCameraSession) {
            MULTI_DEBUG_ORBBEC("orbbecSafeGetDeviceCount:before");
            const uint32_t connectedDevices = orbbecSafeGetDeviceCount();
            MULTI_DEBUG_ORBBEC("orbbecSafeGetDeviceCount:after");
            if (connectedDevices > 1 && config_.deviceSerial.empty()) {
                std::cerr << "[orbbec] WARNING: " << connectedDevices
                          << " Orbbec devices connected. Single-camera mode uses the first device only; "
                             "extra cameras can exhaust Windows hardware video decoders (error 0xc00d3704). "
                             "Unplug unused cameras or use --camera-config for multi-camera.\n"
                          << std::flush;
            }
        }

        std::shared_ptr<ob::Device> device = boundDevice_;
        if (!device && !config_.deviceSerial.empty()) {
            MULTI_DEBUG_ORBBEC("orbbecSafeOpenDeviceBySerial:before");
            if (!orbbecSafeOpenDeviceBySerial(config_.deviceSerial, sdkContext_, device)) {
                throw std::runtime_error("Orbbec device not found for serial: " + config_.deviceSerial);
            }
            MULTI_DEBUG_ORBBEC("orbbecSafeOpenDeviceBySerial:after");
            boundDevice_ = device;
        } else if (!device) {
            std::cerr << "[orbbec] Opening default Orbbec device via Pipeline()\n" << std::flush;
        } else {
            MULTI_DEBUG_ORBBEC("using pre-bound device");
        }

        if (device) {
            if (const auto info = device->getDeviceInfo()) {
                const std::string label = config_.deviceSerial.empty() ? info->name() : config_.deviceSerial;
                std::cerr << "[orbbec] Device: " << label << " (" << info->name() << ")\n" << std::flush;
            }
        }

        OrbbecCaptureMode mode = OrbbecCaptureMode::RgbdD2c;
        std::shared_ptr<ob::Pipeline> pipeline;
        std::shared_ptr<ob::Align> alignFilter;
        std::shared_ptr<ob::PointCloudFilter> pointCloudFilter;

        // Femto Bolt: 1920x1080 MJPG @ 30fps only (native format; RGB probe triggers Win MFT errors).
        const OBFormat colorFormats[] = {OB_FORMAT_MJPG};
        bool started = false;
        for (const OBFormat colorFormat : colorFormats) {
            if (config_.multiCameraSession) {
                std::cerr << "[orbbec] Trying RGBD (color=1280x720 MJPG @ 15fps, multi-camera)...\n" << std::flush;
            } else {
                std::cerr << "[orbbec] Trying RGBD (color=1920x1080 MJPG @ 30fps)...\n" << std::flush;
            }
            try {
                MULTI_DEBUG_ORBBEC("tryStartRgbdPipeline:before");
                if (tryStartRgbdPipeline(device, pipeline, colorFormat, alignFilter, pointCloudFilter)) {
                    MULTI_DEBUG_ORBBEC("tryStartRgbdPipeline:after-success");
                    if (config_.multiCameraSession) {
                        std::cerr << "[orbbec] RGBD active (1280x720 MJPG multi-camera, software Align)\n" << std::flush;
                    } else {
                        std::cerr << "[orbbec] RGBD active (1920x1080 MJPG @ 30fps, software Align)\n" << std::flush;
                    }
                    started = true;
                    break;
                }
            } catch (const ob::Error& error) {
                std::cerr << "[orbbec] D2C " << colorFormatName(colorFormat) << " threw Orbbec error: "
                          << error.getMessage() << "\n"
                          << std::flush;
            } catch (const std::exception& error) {
                std::cerr << "[orbbec] D2C " << colorFormatName(colorFormat)
                          << " threw std::exception (likely SDK fault): " << error.what() << "\n"
                          << std::flush;
            } catch (...) {
                std::cerr << "[orbbec] D2C " << colorFormatName(colorFormat)
                          << " threw unknown exception (likely SDK fault)\n"
                          << std::flush;
            }
            std::cerr << "[orbbec] D2C " << colorFormatName(colorFormat) << " failed, trying next...\n" << std::flush;
            std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        }

        if (!started) {
            std::cerr << "[orbbec] D2C RGBD unavailable, falling back to depth-only point cloud...\n" << std::flush;
            bool depthOnlyStarted = false;
            try {
                depthOnlyStarted = tryStartDepthOnlyPipeline(device, pipeline, pointCloudFilter);
            } catch (const ob::Error& error) {
                std::cerr << "[orbbec] Depth-only threw Orbbec error: " << error.getMessage() << "\n" << std::flush;
            } catch (const std::exception& error) {
                std::cerr << "[orbbec] Depth-only threw std::exception (likely SDK fault): " << error.what() << "\n"
                          << std::flush;
            } catch (...) {
                std::cerr << "[orbbec] Depth-only threw unknown exception (likely SDK fault)\n" << std::flush;
            }

            if (!depthOnlyStarted) {
                throw std::runtime_error(
                    "Orbbec pipeline.start() failed. On Windows this is often "
                    "0xc00d3704 (hardware video decoder exhausted): close Orbbec Viewer, "
                    "stop other camera apps, unplug extra cameras, then retry.");
            }
            mode = OrbbecCaptureMode::DepthOnly;
            std::cerr << "[orbbec] Depth-only pipeline active (OB_FORMAT_POINT, gray attributes)\n" << std::flush;
        }

        logOrbbecDevice(pipeline);

        MULTI_DEBUG_ORBBEC("warmup-frames:start");
        for (int i = 0; i < 15 && !stopToken.stop_requested(); ++i) {
            if (config_.multiCameraSession) {
                MULTI_DEBUG_ORBBEC_STR("warmup waitForFrameset i=" + std::to_string(i));
            }
            orbbecSafeWaitForFrameset(*pipeline, 200);
        }
        MULTI_DEBUG_ORBBEC("warmup-frames:done");

        pipelineReady_ = true;
        MULTI_DEBUG_ORBBEC("onPipelineReady:before");
        if (config_.onPipelineReady) {
            config_.onPipelineReady();
        }
        MULTI_DEBUG_ORBBEC("onPipelineReady:after");

        uint64_t frameNumber = 0;
        float minX = 0.F;
        float minY = 0.F;
        float minZ = 0.F;
        float quantScale = 0.F;
        bool originInitialized = false;
        auto lastWaitLog = std::chrono::steady_clock::now();

        while (!stopToken.stop_requested() && running_) {
            if (config_.multiCameraSession && (frameNumber < 3U || frameNumber % 50U == 0U)) {
                MULTI_DEBUG_ORBBEC_STR("frame-loop waitForFrameset frame=" + std::to_string(frameNumber));
            }
            auto frameSet = orbbecSafeWaitForFrameset(*pipeline, 1000);
            if (config_.multiCameraSession && (frameNumber < 3U || frameNumber % 50U == 0U)) {
                MULTI_DEBUG_ORBBEC_STR("frame-loop waitForFrameset returned frame=" + std::to_string(frameNumber));
            }

            if (mode == OrbbecCaptureMode::RgbdD2c) {
                if (!frameSet || !frameSet->depthFrame() || !frameSet->colorFrame()) {
                    const auto now = std::chrono::steady_clock::now();
                    if (now - lastWaitLog >= std::chrono::seconds(5)) {
                        std::cerr << "[orbbec] Waiting for synchronized color+depth...\n" << std::flush;
                        lastWaitLog = now;
                    }
                    continue;
                }
            } else if (!frameSet || !frameSet->depthFrame()) {
                const auto now = std::chrono::steady_clock::now();
                if (now - lastWaitLog >= std::chrono::seconds(5)) {
                    std::cerr << "[orbbec] Waiting for depth frames...\n" << std::flush;
                    lastWaitLog = now;
                }
                continue;
            }
            lastWaitLog = std::chrono::steady_clock::now();

            std::shared_ptr<ob::Frame> cloudFrame;
            if (mode == OrbbecCaptureMode::RgbdD2c) {
                if (config_.multiCameraSession && (frameNumber < 3U || frameNumber % 50U == 0U)) {
                    MULTI_DEBUG_ORBBEC_STR("frame-loop processRgbdPointCloud frame=" + std::to_string(frameNumber));
                }
                if (alignFilter) {
                    cloudFrame = orbbecSafeProcessRgbdPointCloud(*alignFilter, *pointCloudFilter, frameSet);
                } else {
                    cloudFrame = orbbecSafeProcessFrameSetPointCloud(*pointCloudFilter, frameSet);
                }
            } else {
                if (config_.multiCameraSession && (frameNumber < 3U || frameNumber % 50U == 0U)) {
                    MULTI_DEBUG_ORBBEC_STR("frame-loop processDepthPointCloud frame=" + std::to_string(frameNumber));
                }
                cloudFrame = orbbecSafeProcessDepthPointCloud(*pointCloudFilter, frameSet->depthFrame());
            }
            if (!cloudFrame) {
                continue;
            }

            PointCloudFrame frame;
            frame.frameNumber = frameNumber++;

            if (mode == OrbbecCaptureMode::RgbdD2c) {
                if (cloudFrame->format() != OB_FORMAT_RGB_POINT ||
                    cloudFrame->dataSize() < sizeof(OBColorPoint)) {
                    continue;
                }

                const auto* points = reinterpret_cast<const OBColorPoint*>(cloudFrame->data());
                const uint32_t pointCount = cloudFrame->dataSize() / static_cast<uint32_t>(sizeof(OBColorPoint));
                if (pointCount == 0) {
                    continue;
                }

                const uint32_t stride =
                    (config_.maxPointsPerFrame > 0 && pointCount > config_.maxPointsPerFrame)
                        ? static_cast<uint32_t>((pointCount + config_.maxPointsPerFrame - 1) /
                                                config_.maxPointsPerFrame)
                        : 1U;

                if (config_.onWorldSliceCaptured) {
                    if (config_.multiCameraSession && (frame.frameNumber < 3U || frame.frameNumber % 50U == 0U)) {
                        MULTI_DEBUG_ORBBEC_STR(
                            "emitWorldSliceFromRgbPoints frame=" + std::to_string(frame.frameNumber));
                    }
                    emitWorldSliceFromRgbPoints(frame.frameNumber, points, pointCount, stride);
                    if (frame.frameNumber == 0) {
                        std::cerr << "[orbbec] First D2C world slice: raw=" << pointCount << " stride=" << stride
                                  << "\n"
                                  << std::flush;
                    }
                    continue;
                }

                if (!originInitialized) {
                    float maxX = points[0].x;
                    float maxY = points[0].y;
                    float maxZ = points[0].z;
                    minX = points[0].x;
                    minY = points[0].y;
                    minZ = points[0].z;
                    for (uint32_t i = 1; i < pointCount; ++i) {
                        if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                            continue;
                        }
                        minX = (std::min)(minX, points[i].x);
                        minY = (std::min)(minY, points[i].y);
                        minZ = (std::min)(minZ, points[i].z);
                        maxX = (std::max)(maxX, points[i].x);
                        maxY = (std::max)(maxY, points[i].y);
                        maxZ = (std::max)(maxZ, points[i].z);
                    }
                    const float extentX = maxX - minX;
                    const float extentY = maxY - minY;
                    const float extentZ = maxZ - minZ;
                    const float maxExtent = (std::max)(extentX, (std::max)(extentY, extentZ));
                    const float maxVoxel =
                        static_cast<float>((static_cast<uint32_t>(1) << config_.geoBitDepthInput) - 1U);
                    quantScale = maxExtent > 1e-6F ? maxVoxel / maxExtent : 1.F;
                    originInitialized = true;
                    std::cerr << "[orbbec] D2C scene extent " << maxExtent << " mm, quant scale " << quantScale << "\n"
                              << std::flush;
                }

                const uint32_t reserveCount =
                    (std::min)(pointCount / stride, static_cast<uint32_t>(config_.maxPointsPerFrame));

                frame.origin[0] = minX;
                frame.origin[1] = minY;
                frame.origin[2] = minZ;
                frame.quantScale = quantScale;
                frame.geometry.reserve(reserveCount);
                frame.attributes.reserve(reserveCount);

                for (uint32_t i = 0; i < pointCount; i += stride) {
                    if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                        continue;
                    }

                    const auto qx = quantizeCoord(points[i].x, minX, quantScale, config_.geoBitDepthInput);
                    const auto qy = quantizeCoord(points[i].y, minY, quantScale, config_.geoBitDepthInput);
                    const auto qz = quantizeCoord(points[i].z, minZ, quantScale, config_.geoBitDepthInput);
                    const GeometryPoint geometry{qx, qy, qz};
                    if (!coordinateFitsVoxelGrid(geometry, config_.geoBitDepthInput)) {
                        continue;
                    }

                    frame.geometry.push_back(geometry);
                    frame.attributes.push_back(AttributePoint{
                        colorChannelToByte(points[i].r),
                        colorChannelToByte(points[i].g),
                        colorChannelToByte(points[i].b)});
                }

                if (frame.frameNumber == 0 && !frame.geometry.empty()) {
                    std::cerr << "[orbbec] First D2C cloud: raw=" << pointCount << " kept=" << frame.geometry.size()
                              << " stride=" << stride << "\n"
                              << std::flush;
                }
            } else {
                if (cloudFrame->format() != OB_FORMAT_POINT || cloudFrame->dataSize() < sizeof(OBPoint)) {
                    continue;
                }

                const auto* points = reinterpret_cast<const OBPoint*>(cloudFrame->data());
                const uint32_t pointCount = cloudFrame->dataSize() / static_cast<uint32_t>(sizeof(OBPoint));
                if (pointCount == 0) {
                    continue;
                }

                const uint32_t stride =
                    (config_.maxPointsPerFrame > 0 && pointCount > config_.maxPointsPerFrame)
                        ? static_cast<uint32_t>((pointCount + config_.maxPointsPerFrame - 1) /
                                                config_.maxPointsPerFrame)
                        : 1U;

                if (config_.onWorldSliceCaptured) {
                    emitWorldSliceFromDepthPoints(frame.frameNumber, points, pointCount, stride);
                    if (frame.frameNumber == 0) {
                        std::cerr << "[orbbec] First depth world slice: raw=" << pointCount << " stride=" << stride
                                  << "\n"
                                  << std::flush;
                    }
                    continue;
                }

                if (!originInitialized) {
                    float maxX = points[0].x;
                    float maxY = points[0].y;
                    float maxZ = points[0].z;
                    minX = points[0].x;
                    minY = points[0].y;
                    minZ = points[0].z;
                    for (uint32_t i = 1; i < pointCount; ++i) {
                        if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                            continue;
                        }
                        minX = (std::min)(minX, points[i].x);
                        minY = (std::min)(minY, points[i].y);
                        minZ = (std::min)(minZ, points[i].z);
                        maxX = (std::max)(maxX, points[i].x);
                        maxY = (std::max)(maxY, points[i].y);
                        maxZ = (std::max)(maxZ, points[i].z);
                    }
                    const float extentX = maxX - minX;
                    const float extentY = maxY - minY;
                    const float extentZ = maxZ - minZ;
                    const float maxExtent = (std::max)(extentX, (std::max)(extentY, extentZ));
                    const float maxVoxel =
                        static_cast<float>((static_cast<uint32_t>(1) << config_.geoBitDepthInput) - 1U);
                    quantScale = maxExtent > 1e-6F ? maxVoxel / maxExtent : 1.F;
                    originInitialized = true;
                    std::cerr << "[orbbec] Depth scene extent " << maxExtent << " mm, quant scale " << quantScale
                              << "\n"
                              << std::flush;
                }

                const uint32_t reserveCount =
                    (std::min)(pointCount / stride, static_cast<uint32_t>(config_.maxPointsPerFrame));

                frame.origin[0] = minX;
                frame.origin[1] = minY;
                frame.origin[2] = minZ;
                frame.quantScale = quantScale;
                frame.geometry.reserve(reserveCount);
                frame.attributes.reserve(reserveCount);

                for (uint32_t i = 0; i < pointCount; i += stride) {
                    if (points[i].z < kMinDepthMm || points[i].z > kMaxDepthMm) {
                        continue;
                    }

                    const auto qx = quantizeCoord(points[i].x, minX, quantScale, config_.geoBitDepthInput);
                    const auto qy = quantizeCoord(points[i].y, minY, quantScale, config_.geoBitDepthInput);
                    const auto qz = quantizeCoord(points[i].z, minZ, quantScale, config_.geoBitDepthInput);
                    const GeometryPoint geometry{qx, qy, qz};
                    if (!coordinateFitsVoxelGrid(geometry, config_.geoBitDepthInput)) {
                        continue;
                    }

                    const uint8_t gray = static_cast<uint8_t>(
                        (std::max)(0.F, (std::min)(255.F, (points[i].z - kMinDepthMm) / (kMaxDepthMm - kMinDepthMm) * 255.F)));
                    frame.geometry.push_back(geometry);
                    frame.attributes.push_back(AttributePoint{gray, gray, gray});
                }

                if (frame.frameNumber == 0 && !frame.geometry.empty()) {
                    std::cerr << "[orbbec] First depth cloud: raw=" << pointCount << " kept=" << frame.geometry.size()
                              << " stride=" << stride << "\n"
                              << std::flush;
                }
            }

            if (frame.geometry.empty()) {
                continue;
            }
            pushFrame(std::move(frame));
        }

        orbbecSafePipelineStop(*pipeline);
    }
#endif

    void captureLoopSynthetic(std::stop_token stopToken) {
        uint64_t frameNumber = 0;
        const float scale = static_cast<float>(1 << config_.geoBitDepthInput);

        while (!stopToken.stop_requested() && running_) {
            PointCloudFrame frame;
            frame.frameNumber = frameNumber++;
            frame.quantScale = 1.F;
            frame.geometry.reserve(4096);
            frame.attributes.reserve(4096);

            for (int y = 0; y < 64; ++y) {
                for (int x = 0; x < 64; ++x) {
                    const float xf = static_cast<float>(x) / 64.F;
                    const float yf = static_cast<float>(y) / 64.F;
                    const float zf = 0.35F + 0.15F * std::sin((xf + yf + frameNumber * 0.05F) * 6.2831853F);

                    const auto qx = static_cast<uvgvpcc_enc::typeGeometryInput>(xf * scale * 0.5F);
                    const auto qy = static_cast<uvgvpcc_enc::typeGeometryInput>(yf * scale * 0.5F);
                    const auto qz = static_cast<uvgvpcc_enc::typeGeometryInput>(zf * scale * 0.5F);
                    const GeometryPoint geometry{qx, qy, qz};
                    if (!coordinateFitsVoxelGrid(geometry, config_.geoBitDepthInput)) {
                        continue;
                    }

                    frame.geometry.push_back(geometry);
                    frame.attributes.push_back(AttributePoint{
                        static_cast<uint8_t>(xf * 255.F),
                        static_cast<uint8_t>(yf * 255.F),
                        static_cast<uint8_t>(128 + 127 * std::sin(xf * 6.2831853F)),
                    });
                }
            }

            pushFrame(std::move(frame));
            std::this_thread::sleep_for(std::chrono::milliseconds(1000 / (std::max)(1, config_.colorFps)));
        }
    }

    OrbbecCaptureConfig config_;
#if defined(ORBBEC_SDK_FOUND)
    std::shared_ptr<ob::Device> boundDevice_;
    std::shared_ptr<ob::Context> sdkContext_;
#endif
    std::atomic<bool> running_{false};
    std::atomic<bool> captureFailed_{false};
    std::atomic<bool> pipelineReady_{false};
    mutable uvgutils::sync_mutex captureErrorMutex_;
    std::string captureError_;
    std::jthread captureThread_;
    uvgutils::sync_mutex queueMutex_;
    std::deque<PointCloudFrame> queue_;
};
